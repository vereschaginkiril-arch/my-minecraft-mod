/*
# КласКвіз — Quiz Game Schema

1. New Tables
- `quizzes`: stores user-created quizzes (title + questions as JSONB)
- `rooms`: multiplayer game rooms with a 6-char join code
- `players`: players joined to a room (nickname, score, answers)
- `question_state`: single row tracking the host's current question index for a room
2. Storage
- Public bucket `quiz-images` for question photos
3. Security
- RLS enabled on all tables
- Single-tenant no-auth app: grants to anon + authenticated, public policies
- Storage bucket is public-read, authenticated/anon-write
*/

-- ============ quizzes ============
CREATE TABLE IF NOT EXISTS quizzes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Без назви',
  questions jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE quizzes ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON quizzes TO anon, authenticated;

DROP POLICY IF EXISTS "quiz_select_all" ON quizzes;
CREATE POLICY "quiz_select_all" ON quizzes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "quiz_insert_all" ON quizzes;
CREATE POLICY "quiz_insert_all" ON quizzes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "quiz_update_all" ON quizzes;
CREATE POLICY "quiz_update_all" ON quizzes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "quiz_delete_all" ON quizzes;
CREATE POLICY "quiz_delete_all" ON quizzes FOR DELETE
  TO anon, authenticated USING (true);

-- ============ rooms ============
CREATE TABLE IF NOT EXISTS rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  quiz_id uuid NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
  host_token uuid NOT NULL DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'waiting', -- waiting | playing | finished
  current_index int NOT NULL DEFAULT 0,
  show_results boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE rooms ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON rooms TO anon, authenticated;

DROP POLICY IF EXISTS "room_select_all" ON rooms;
CREATE POLICY "room_select_all" ON rooms FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "room_insert_all" ON rooms;
CREATE POLICY "room_insert_all" ON rooms FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "room_update_all" ON rooms;
CREATE POLICY "room_update_all" ON rooms FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "room_delete_all" ON rooms;
CREATE POLICY "room_delete_all" ON rooms FOR DELETE
  TO anon, authenticated USING (true);

-- ============ players ============
CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  nickname text NOT NULL,
  score int NOT NULL DEFAULT 0,
  answers jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, nickname)
);

ALTER TABLE players ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON players TO anon, authenticated;

DROP POLICY IF EXISTS "player_select_all" ON players;
CREATE POLICY "player_select_all" ON players FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "player_insert_all" ON players;
CREATE POLICY "player_insert_all" ON players FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "player_update_all" ON players;
CREATE POLICY "player_update_all" ON players FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "player_delete_all" ON players;
CREATE POLICY "player_delete_all" ON players FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_rooms_code ON rooms(code);
CREATE INDEX IF NOT EXISTS idx_players_room ON players(room_id);
CREATE INDEX IF NOT EXISTS idx_quizzes_created ON quizzes(created_at DESC);

-- ============ Storage bucket ============
INSERT INTO storage.buckets (id, name, public)
VALUES ('quiz-images', 'quiz-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: public read, anon+authenticated write
DROP POLICY IF EXISTS "quiz_images_read" ON storage.objects;
CREATE POLICY "quiz_images_read" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'quiz-images');

DROP POLICY IF EXISTS "quiz_images_insert" ON storage.objects;
CREATE POLICY "quiz_images_insert" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'quiz-images');

DROP POLICY IF EXISTS "quiz_images_update" ON storage.objects;
CREATE POLICY "quiz_images_update" ON storage.objects FOR UPDATE
  TO anon, authenticated USING (bucket_id = 'quiz-images') WITH CHECK (bucket_id = 'quiz-images');

DROP POLICY IF EXISTS "quiz_images_delete" ON storage.objects;
CREATE POLICY "quiz_images_delete" ON storage.objects FOR DELETE
  TO anon, authenticated USING (bucket_id = 'quiz-images');
