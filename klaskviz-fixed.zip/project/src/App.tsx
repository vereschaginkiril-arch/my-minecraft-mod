import { useState, useCallback, useEffect } from 'react';
import type { View } from '@/lib/types';
import { Dashboard } from '@/pages/Dashboard';
import { Editor } from '@/pages/Editor';
import { Modes } from '@/pages/Modes';
import { Solo } from '@/pages/Solo';
import { Host } from '@/pages/Host';
import { Join } from '@/pages/Join';
import { PlayerRoom } from '@/pages/PlayerRoom';

function parseHashView(): View {
  const hash = window.location.hash.replace(/^#/, '');
  const params = new URLSearchParams(hash);
  const joinCode = params.get('join');
  if (joinCode) {
    return { name: 'join', prefillCode: joinCode.toUpperCase() };
  }
  return { name: 'dashboard' };
}

function App() {
  const [view, setView] = useState<View>(() => parseHashView());

  const goDashboard = useCallback(() => {
    window.location.hash = '';
    setView({ name: 'dashboard' });
  }, []);

  // listen for hash changes (back/forward, manual edit)
  useEffect(() => {
    function onHashChange() {
      const v = parseHashView();
      if (v.name === 'join') setView(v);
    }
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  if (view.name === 'dashboard') {
    return (
      <Dashboard
        onOpenEditor={(quizId) => setView({ name: 'editor', quizId })}
        onOpenModes={(quizId) => setView({ name: 'modes', quizId })}
        onCreateRoom={(quizId) => setView({ name: 'modes', quizId })}
        onJoinRoom={() => setView({ name: 'join' })}
      />
    );
  }

  if (view.name === 'editor') {
    return (
      <Editor
        quizId={view.quizId ?? ''}
        onBack={goDashboard}
        onDone={(quizId) => setView({ name: 'modes', quizId })}
      />
    );
  }

  if (view.name === 'modes') {
    return (
      <Modes
        quizId={view.quizId}
        onBack={goDashboard}
        onSolo={(quizId) => setView({ name: 'solo', quizId })}
        onHost={(roomId) => setView({ name: 'host', roomId })}
        onJoin={() => setView({ name: 'join' })}
      />
    );
  }

  if (view.name === 'solo') {
    return <Solo quizId={view.quizId} onBack={goDashboard} onHome={goDashboard} />;
  }

  if (view.name === 'host') {
    return <Host roomId={view.roomId} onBack={goDashboard} onHome={goDashboard} />;
  }

  if (view.name === 'join') {
    return (
      <Join
        prefillCode={view.prefillCode}
        onBack={goDashboard}
        onJoinRoom={(roomId) => setView({ name: 'player', roomId, playerId: '' })}
      />
    );
  }

  if (view.name === 'player') {
    return <PlayerRoom roomId={view.roomId} onBack={goDashboard} onHome={goDashboard} />;
  }

  return null;
}

export default App;
