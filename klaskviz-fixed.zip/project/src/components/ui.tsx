import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

interface DropdownMenuProps {
  items: { label: string; icon: ReactNode; onClick: () => void; danger?: boolean }[];
  onClose: () => void;
  triggerRect: { top: number; left: number; width: number; height: number };
}

export function DropdownMenu({ items, onClose, triggerRect }: DropdownMenuProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    }
    function handleEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  // position menu — flip up if not enough space below
  const spaceBelow = window.innerHeight - triggerRect.top - triggerRect.height;
  const openUp = spaceBelow < items.length * 48 + 16;
  const top = openUp ? triggerRect.top - items.length * 48 - 8 : triggerRect.top + triggerRect.height + 4;
  const left = Math.min(triggerRect.left, window.innerWidth - 220);

  return (
    <div
      ref={ref}
      className="fixed z-50 w-52 rounded-2xl bg-slate-800/95 backdrop-blur-md shadow-2xl ring-1 ring-white/10 overflow-hidden animate-scale-in"
      style={{ top, left }}
    >
      {items.map((item, i) => (
        <button
          key={i}
          onClick={() => {
            item.onClick();
            onClose();
          }}
          className={`flex w-full items-center gap-3 px-4 py-3 text-left text-sm font-semibold transition-colors hover:bg-white/10 ${
            item.danger ? 'text-red-400 hover:text-red-300' : 'text-white'
          }`}
        >
          <span className="shrink-0">{item.icon}</span>
          {item.label}
        </button>
      ))}
    </div>
  );
}

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  maxWidth?: string;
}

export function Modal({ open, onClose, children, title, maxWidth = 'max-w-md' }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    function handleEsc(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className={`w-full ${maxWidth} rounded-3xl bg-slate-800 ring-1 ring-white/10 shadow-2xl animate-scale-in`}
        onClick={(e) => e.stopPropagation()}
      >
        {title && (
          <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
            <h2 className="text-lg font-extrabold">{title}</h2>
            <button
              onClick={onClose}
              className="rounded-full p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
