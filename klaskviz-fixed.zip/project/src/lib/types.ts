export type QuestionType = 'text' | 'image';

export interface QuestionOption {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  type: QuestionType;
  prompt: string;
  options: QuestionOption[];
  correctOptionId: string;
  timeLimit: number; // seconds
  imagePath: string | null; // storage path for uploaded image
  imageUrl: string | null; // resolved public URL
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
  created_at: string;
  updated_at: string;
}

export type RoomStatus = 'waiting' | 'playing' | 'finished';

export interface Room {
  id: string;
  code: string;
  quiz_id: string;
  host_token: string;
  status: RoomStatus;
  current_index: number;
  show_results: boolean;
  created_at: string;
}

export interface Player {
  id: string;
  room_id: string;
  nickname: string;
  score: number;
  answers: PlayerAnswer[];
  created_at: string;
}

export interface PlayerAnswer {
  questionId: string;
  optionId: string;
  correct: boolean;
  timeMs: number;
  points: number;
}

export type GameMode = 'solo' | 'host' | 'join';
export type View =
  | { name: 'dashboard' }
  | { name: 'editor'; quizId: string | null }
  | { name: 'modes'; quizId: string }
  | { name: 'solo'; quizId: string }
  | { name: 'host'; roomId: string }
  | { name: 'join'; prefillCode?: string }
  | { name: 'player'; roomId: string; playerId: string };

export function emptyQuestion(): Question {
  const opts = [
    { id: crypto.randomUUID(), text: '' },
    { id: crypto.randomUUID(), text: '' },
    { id: crypto.randomUUID(), text: '' },
    { id: crypto.randomUUID(), text: '' },
  ];
  return {
    id: crypto.randomUUID(),
    type: 'text',
    prompt: '',
    options: opts,
    correctOptionId: opts[0].id,
    timeLimit: 20,
    imagePath: null,
    imageUrl: null,
  };
}

export function randomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}
