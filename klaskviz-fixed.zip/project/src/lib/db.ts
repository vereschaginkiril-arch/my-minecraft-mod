import { supabase } from './supabase';
import { randomCode } from './types';
import type { Quiz, Question, Room, Player, PlayerAnswer } from './types';

// ---------- Quizzes ----------

export async function fetchQuizzes(): Promise<Quiz[]> {
  const { data, error } = await supabase
    .from('quizzes')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(quizRowToType);
}

export async function fetchQuiz(id: string): Promise<Quiz | null> {
  const { data, error } = await supabase.from('quizzes').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data ? quizRowToType(data) : null;
}

export async function createQuiz(title: string = 'Без назви'): Promise<Quiz> {
  const { data, error } = await supabase
    .from('quizzes')
    .insert({ title, questions: [] })
    .select('*')
    .single();
  if (error) throw error;
  return quizRowToType(data);
}

export async function saveQuiz(id: string, title: string, questions: Question[]): Promise<void> {
  const { error } = await supabase
    .from('quizzes')
    .update({ title, questions: questions as unknown as Record<string, unknown>[], updated_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
}

export async function duplicateQuiz(id: string): Promise<Quiz | null> {
  const original = await fetchQuiz(id);
  if (!original) return null;
  const { data, error } = await supabase
    .from('quizzes')
    .insert({
      title: `${original.title} (копія)`,
      questions: original.questions as unknown as Record<string, unknown>[],
    })
    .select('*')
    .single();
  if (error) throw error;
  return quizRowToType(data);
}

export async function deleteQuiz(id: string): Promise<void> {
  const { error } = await supabase.from('quizzes').delete().eq('id', id);
  if (error) throw error;
}

function quizRowToType(row: {
  id: string;
  title: string;
  questions: unknown;
  created_at: string;
  updated_at: string;
}): Quiz {
  const qs = (Array.isArray(row.questions) ? row.questions : []) as Question[];
  for (const q of qs) {
    if (q.imagePath) {
      const { data } = supabase.storage.from('quiz-images').getPublicUrl(q.imagePath);
      q.imageUrl = data.publicUrl;
    } else {
      q.imageUrl = null;
    }
  }
  return {
    id: row.id,
    title: row.title,
    questions: qs,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

// ---------- Image upload ----------

export async function uploadQuestionImage(file: File, quizId: string): Promise<{ path: string; url: string }> {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'png';
  const path = `${quizId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from('quiz-images').upload(path, file, { upsert: false });
  if (error) throw error;
  const { data } = supabase.storage.from('quiz-images').getPublicUrl(path);
  return { path, url: data.publicUrl };
}

export async function deleteQuestionImage(path: string): Promise<void> {
  await supabase.storage.from('quiz-images').remove([path]);
}

// ---------- Rooms ----------

export async function createRoom(quizId: string): Promise<{ room: Room; quiz: Quiz }> {
  const quiz = await fetchQuiz(quizId);
  if (!quiz) throw new Error('Вікторину не знайдено');

  // try unique code
  let code = randomCode();
  let attempts = 0;
  while (attempts < 5) {
    const { data: existing } = await supabase.from('rooms').select('id').eq('code', code).maybeSingle();
    if (!existing) break;
    code = randomCode();
    attempts++;
  }

  const { data, error } = await supabase
    .from('rooms')
    .insert({ code, quiz_id: quizId, status: 'waiting', current_index: 0, show_results: false })
    .select('*')
    .single();
  if (error) throw error;
  return { room: roomRowToType(data), quiz };
}

export async function fetchRoomByCode(code: string): Promise<{ room: Room; quiz: Quiz } | null> {
  const { data, error } = await supabase
    .from('rooms')
    .select('*, quizzes(*)')
    .eq('code', code.toUpperCase())
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;
  const quiz = quizRowToType(data.quizzes);
  const room = roomRowToType(data);
  return { room, quiz };
}

export async function fetchRoom(id: string): Promise<Room | null> {
  const { data, error } = await supabase.from('rooms').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data ? roomRowToType(data) : null;
}

export async function fetchRoomWithQuiz(id: string): Promise<{ room: Room; quiz: Quiz } | null> {
  const { data, error } = await supabase
    .from('rooms')
    .select('*, quizzes(*)')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;
  return { room: roomRowToType(data), quiz: quizRowToType(data.quizzes) };
}

export async function updateRoom(
  id: string,
  patch: Partial<Pick<Room, 'status' | 'current_index' | 'show_results'>>,
): Promise<void> {
  const { error } = await supabase.from('rooms').update(patch).eq('id', id);
  if (error) throw error;
}

function roomRowToType(row: {
  id: string;
  code: string;
  quiz_id: string;
  host_token: string;
  status: Room['status'];
  current_index: number;
  show_results: boolean;
  created_at: string;
}): Room {
  return {
    id: row.id,
    code: row.code,
    quiz_id: row.quiz_id,
    host_token: row.host_token,
    status: row.status,
    current_index: row.current_index,
    show_results: row.show_results,
    created_at: row.created_at,
  };
}

// ---------- Players ----------

export async function joinRoom(roomId: string, nickname: string): Promise<Player | null> {
  // upsert by (room_id, nickname)
  const { data: existing } = await supabase
    .from('players')
    .select('*')
    .eq('room_id', roomId)
    .eq('nickname', nickname)
    .maybeSingle();
  if (existing) return playerRowToType(existing);

  const { data, error } = await supabase
    .from('players')
    .insert({ room_id: roomId, nickname, answers: [] })
    .select('*')
    .single();
  if (error) throw error;
  return playerRowToType(data);
}

export async function fetchPlayers(roomId: string): Promise<Player[]> {
  const { data, error } = await supabase
    .from('players')
    .select('*')
    .eq('room_id', roomId)
    .order('score', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(playerRowToType);
}

export async function submitAnswer(
  playerId: string,
  roomId: string,
  answer: PlayerAnswer,
): Promise<void> {
  // fetch existing answers, append, recompute score, update
  const { data, error } = await supabase
    .from('players')
    .select('answers, score')
    .eq('id', playerId)
    .maybeSingle();
  if (error) throw error;
  if (!data) throw new Error('Гравця не знайдено');
  const answers = Array.isArray(data.answers) ? (data.answers as PlayerAnswer[]) : [];
  const filtered = answers.filter((a) => a.questionId !== answer.questionId);
  filtered.push(answer);
  const score = filtered.reduce((sum, a) => sum + (a.points || 0), 0);
  const { error: updErr } = await supabase
    .from('players')
    .update({ answers: filtered as unknown as Record<string, unknown>[], score })
    .eq('id', playerId);
  if (updErr) throw updErr;
}

function playerRowToType(row: {
  id: string;
  room_id: string;
  nickname: string;
  score: number;
  answers: unknown;
  created_at: string;
}): Player {
  return {
    id: row.id,
    room_id: row.room_id,
    nickname: row.nickname,
    score: row.score,
    answers: Array.isArray(row.answers) ? (row.answers as PlayerAnswer[]) : [],
    created_at: row.created_at,
  };
}
