import { useEffect, useState, useCallback, useRef } from 'react';
import {
  Plus,
  MoreVertical,
  Play,
  Home,
  Pencil,
  Copy,
  Trash2,
  HelpCircle,
  Clock,
  Calendar,
} from 'lucide-react';
import { fetchQuizzes, createQuiz, duplicateQuiz, deleteQuiz } from '@/lib/db';
import type { Quiz } from '@/lib/types';
import { DropdownMenu, Modal } from '@/components/ui';

interface DashboardProps {
  onOpenEditor: (quizId: string) => void;
  onOpenModes: (quizId: string) => void;
  onCreateRoom: (quizId: string) => void;
  onJoinRoom: () => void;
}

export function Dashboard({ onOpenEditor, onOpenModes, onCreateRoom, onJoinRoom }: DashboardProps) {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuFor, setMenuFor] = useState<{ quiz: Quiz; rect: DOMRect } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Quiz | null>(null);
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await fetchQuizzes();
      setQuizzes(data);
    } catch (e) {
      console.error('Failed to load quizzes', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleCreate() {
    setCreating(true);
    try {
      const q = await createQuiz('Без назви');
      onOpenEditor(q.id);
    } catch (e) {
      console.error(e);
      setCreating(false);
    }
  }

  async function handleDuplicate(id: string) {
    try {
      await duplicateQuiz(id);
      await load();
    } catch (e) {
      console.error(e);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteQuiz(id);
      setConfirmDelete(null);
      await load();
    } catch (e) {
      console.error(e);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-900/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-lg shadow-purple-500/30">
              <HelpCircle className="text-white" size={22} />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight">КласКвіз</h1>
              <p className="text-xs text-slate-400">Мої вікторини</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onJoinRoom}
              className="hidden rounded-xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-bold transition hover:bg-white/10 sm:flex sm:items-center sm:gap-2"
            >
              <Home size={16} /> Приєднатись
            </button>
            <button
              onClick={handleCreate}
              disabled={creating}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-4 py-2.5 text-sm font-extrabold shadow-lg shadow-purple-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
            >
              <Plus size={18} /> Створити
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {/* Hero stats */}
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
          <StatCard label="Вікторин" value={quizzes.length} color="from-fuchsia-500 to-purple-600" />
          <StatCard
            label="Запитань"
            value={quizzes.reduce((s, q) => s + q.questions.length, 0)}
            color="from-sky-500 to-blue-600"
          />
          <StatCard
            label="Запитань у середньому"
            value={quizzes.length ? Math.round(quizzes.reduce((s, q) => s + q.questions.length, 0) / quizzes.length) : 0}
            color="from-amber-500 to-orange-600"
          />
        </div>

        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-44 animate-pulse rounded-3xl bg-white/5" />
            ))}
          </div>
        ) : quizzes.length === 0 ? (
          <EmptyState onCreate={handleCreate} onJoin={onJoinRoom} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {quizzes.map((quiz) => (
              <QuizCard
                key={quiz.id}
                quiz={quiz}
                onMenu={(rect) => setMenuFor({ quiz, rect })}
                onOpenEditor={() => onOpenEditor(quiz.id)}
              />
            ))}
            {/* Add card */}
            <button
              onClick={handleCreate}
              disabled={creating}
              className="group flex min-h-44 flex-col items-center justify-center gap-3 rounded-3xl border-2 border-dashed border-white/15 text-slate-400 transition hover:border-purple-400/60 hover:text-white disabled:opacity-60"
            >
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white/5 transition group-hover:bg-purple-500/20">
                <Plus size={28} />
              </div>
              <span className="font-bold">Нова вікторина</span>
            </button>
          </div>
        )}
      </main>

      {menuFor && (
        <DropdownMenu
          triggerRect={menuFor.rect}
          onClose={() => setMenuFor(null)}
          items={[
            { label: 'Запустити', icon: <Play size={16} />, onClick: () => onOpenModes(menuFor.quiz.id) },
            { label: 'Створити кімнату', icon: <Home size={16} />, onClick: () => onCreateRoom(menuFor.quiz.id) },
            { label: 'Редагувати', icon: <Pencil size={16} />, onClick: () => onOpenEditor(menuFor.quiz.id) },
            { label: 'Копіювати тест', icon: <Copy size={16} />, onClick: () => handleDuplicate(menuFor.quiz.id) },
            {
              label: 'Видалити',
              icon: <Trash2 size={16} />,
              danger: true,
              onClick: () => setConfirmDelete(menuFor.quiz),
            },
          ]}
        />
      )}

      <Modal open={!!confirmDelete} onClose={() => setConfirmDelete(null)} title="Видалити вікторину?">
        <p className="mb-6 text-slate-300">
          «{confirmDelete?.title}» буде видалено назавжди. Цю дію не можна скасувати.
        </p>
        <div className="flex gap-3">
          <button
            onClick={() => setConfirmDelete(null)}
            className="flex-1 rounded-xl border border-white/15 bg-white/5 py-3 font-bold transition hover:bg-white/10"
          >
            Скасувати
          </button>
          <button
            onClick={() => confirmDelete && handleDelete(confirmDelete.id)}
            className="flex-1 rounded-xl bg-red-500 py-3 font-bold transition hover:bg-red-600 active:scale-95"
          >
            Видалити
          </button>
        </div>
      </Modal>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <div className={`mb-2 inline-flex rounded-lg bg-gradient-to-br ${color} px-2 py-1 text-xs font-extrabold`}>
        {label}
      </div>
      <div className="text-3xl font-black">{value}</div>
    </div>
  );
}

function QuizCard({
  quiz,
  onMenu,
  onOpenEditor,
}: {
  quiz: Quiz;
  onMenu: (rect: DOMRect) => void;
  onOpenEditor: () => void;
}) {
  const menuRef = useRef<HTMLButtonElement>(null);
  const date = new Date(quiz.created_at).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <div
      className="group relative flex min-h-44 flex-col justify-between overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-slate-800 to-slate-900 p-5 transition hover:border-purple-400/40 hover:shadow-xl hover:shadow-purple-500/10 cursor-pointer"
      onClick={onOpenEditor}
    >
      <div className="absolute -right-8 -top-8 h-24 w-24 rounded-full bg-gradient-to-br from-fuchsia-500/20 to-purple-600/20 blur-2xl transition group-hover:scale-150" />
      <div className="relative flex items-start justify-between">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-lg shadow-purple-500/20">
          <HelpCircle size={20} className="text-white" />
        </div>
        <button
          ref={menuRef}
          onClick={(e) => {
            e.stopPropagation();
            const r = menuRef.current?.getBoundingClientRect();
            if (r) onMenu(r);
          }}
          className="rounded-lg p-1.5 text-slate-400 transition hover:bg-white/10 hover:text-white"
        >
          <MoreVertical size={20} />
        </button>
      </div>
      <div className="relative mt-3">
        <h3 className="line-clamp-2 text-lg font-extrabold leading-snug">{quiz.title || 'Без назви'}</h3>
        <div className="mt-3 flex flex-wrap gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <HelpCircle size={13} /> {quiz.questions.length} запитань
          </span>
          <span className="flex items-center gap-1">
            <Clock size={13} />{' '}
            {quiz.questions.length
              ? `${quiz.questions.reduce((s, q) => s + q.timeLimit, 0)} сек`
              : '—'}
          </span>
          <span className="flex items-center gap-1">
            <Calendar size={13} /> {date}
          </span>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ onCreate, onJoin }: { onCreate: () => void; onJoin: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-white/10 py-20 text-center">
      <div className="mb-4 grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-2xl shadow-purple-500/30">
        <HelpCircle size={40} className="text-white" />
      </div>
      <h2 className="text-2xl font-black">Поки що порожньо</h2>
      <p className="mt-2 max-w-sm text-slate-400">
        Створи свою першу вікторину з будь-якою кількістю запитань, фото та відповідей — або приєднайся до наявної
        кімнати.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <button
          onClick={onCreate}
          className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-6 py-3 font-extrabold shadow-lg shadow-purple-500/30 transition hover:brightness-110 active:scale-95"
        >
          <Plus size={20} /> Створити вікторину
        </button>
        <button
          onClick={onJoin}
          className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-6 py-3 font-bold transition hover:bg-white/10"
        >
          <Home size={20} /> Приєднатись до кімнати
        </button>
      </div>
    </div>
  );
}
