import { useEffect, useState, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  Check,
  X,
  Loader2,
  Trophy,
  Users,
  LogOut,
  Clock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { fetchRoomWithQuiz, joinRoom, fetchPlayers, submitAnswer } from '@/lib/db';
import type { Room, Quiz, Player, PlayerAnswer } from '@/lib/types';

interface PlayerRoomProps {
  roomId: string;
  onBack: () => void;
  onHome: () => void;
}

type PlayerPhase = 'nickname' | 'lobby' | 'question' | 'reveal' | 'finished';

const OPTION_COLORS = [
  'bg-rose-500',
  'bg-sky-500',
  'bg-amber-500',
  'bg-emerald-500',
  'bg-violet-500',
  'bg-pink-500',
];

export function PlayerRoom({ roomId, onBack, onHome }: PlayerRoomProps) {
  const [phase, setPhase] = useState<PlayerPhase>('nickname');
  const [nickname, setNickname] = useState('');
  const [player, setPlayer] = useState<Player | null>(null);
  const [room, setRoom] = useState<Room | null>(null);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const answeredRef = useRef(false);

  const refreshPlayers = useCallback(async () => {
    try {
      const ps = await fetchPlayers(roomId);
      setPlayers(ps);
    } catch (e) {
      console.error(e);
    }
  }, [roomId]);

  const loadRoom = useCallback(async () => {
    try {
      const data = await fetchRoomWithQuiz(roomId);
      if (!data) {
        setError('Кімнату не знайдено');
        return;
      }
      setRoom(data.room);
      setQuiz(data.quiz);
      await refreshPlayers();
    } catch (e) {
      console.error(e);
      setError('Не вдалося завантажити кімнату');
    }
  }, [roomId, refreshPlayers]);

  useEffect(() => {
    loadRoom();
  }, [loadRoom]);

  // Poll as a fallback so player counts and room state still sync when
  // Supabase Realtime publication is not configured.
  useEffect(() => {
    if (!roomId) return;
    const poll = window.setInterval(() => {
      void loadRoom();
    }, 2000);
    const handleFocus = () => void loadRoom();
    window.addEventListener('focus', handleFocus);
    return () => {
      window.clearInterval(poll);
      window.removeEventListener('focus', handleFocus);
    };
  }, [roomId, loadRoom]);

  // realtime: watch room changes
  useEffect(() => {
    if (!roomId) return;
    const channel = supabase
      .channel(`player-${roomId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` },
        (payload) => {
          const r = payload.new as Room;
          setRoom(r);
        },
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'players', filter: `room_id=eq.${roomId}` },
        () => refreshPlayers(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId, refreshPlayers]);

  // react to room state changes
  useEffect(() => {
    if (!room || !player) return;
    if (room.status === 'waiting') {
      setPhase('lobby');
      setSelected(null);
      answeredRef.current = false;
    } else if (room.status === 'playing') {
      if (room.show_results) {
        setPhase('reveal');
      } else {
        setPhase('question');
        setSelected(null);
        answeredRef.current = false;
        const q = quiz?.questions[room.current_index];
        if (q) setTimeLeft(q.timeLimit);
      }
    } else if (room.status === 'finished') {
      setPhase('finished');
    }
  }, [room?.status, room?.current_index, room?.show_results, player, quiz]);

  // countdown for question
  useEffect(() => {
    if (phase !== 'question') {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      return;
    }
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => Math.max(0, t - 1));
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase, room?.current_index]);

  async function handleJoinGame() {
    const name = nickname.trim();
    if (name.length < 2) {
      setError("Введи ім'я (мінімум 2 символи)");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const p = await joinRoom(roomId, name);
      if (!p) {
        setError('Не вдалося приєднатись');
        setLoading(false);
        return;
      }
      setPlayer(p);
      setPhase('lobby');
    } catch (e) {
      console.error(e);
      setError('Не вдалося приєднатись. Спробуй ще раз.');
    } finally {
      setLoading(false);
    }
  }

  async function handleAnswer(optionId: string) {
    if (!player || !room || !quiz || answeredRef.current) return;
    answeredRef.current = true;
    setSelected(optionId);
    const q = quiz.questions[room.current_index];
    const correct = optionId === q.correctOptionId;
    let points = 0;
    if (correct) {
      points = Math.round(100 + (1000 * timeLeft) / q.timeLimit);
    }
    const answer: PlayerAnswer = {
      questionId: q.id,
      optionId,
      correct,
      timeMs: 0,
      points,
    };
    try {
      await submitAnswer(player.id, roomId, answer);
      setPlayer((p) => (p ? { ...p, score: p.score + points, answers: [...p.answers, answer] } : p));
    } catch (e) {
      console.error(e);
    }
  }

  // ---- Nickname entry ----
  if (phase === 'nickname') {
    return (
      <div className="flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
        <header className="flex items-center gap-3 px-4 py-4">
          <button
            onClick={onBack}
            className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
          >
            <ArrowLeft size={18} />
          </button>
        </header>
        <main className="flex flex-1 flex-col items-center justify-center px-4">
          <div className="w-full max-w-sm text-center">
            {error && !room ? (
              <>
                <p className="text-red-400">{error}</p>
                <button onClick={onBack} className="mt-4 rounded-xl bg-white/10 px-4 py-2 font-bold">
                  Назад
                </button>
              </>
            ) : (
              <>
                {quiz && (
                  <p className="mb-2 text-sm text-slate-400">
                    Приєднання до: <span className="font-bold text-white">{quiz.title}</span>
                  </p>
                )}
                <div className="mb-6 grid h-20 w-20 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-2xl shadow-purple-500/40">
                  <Users size={40} className="text-white" />
                </div>
                <h1 className="text-2xl font-black">Як тебе звати?</h1>
                <input
                  value={nickname}
                  onChange={(e) => {
                    setNickname(e.target.value.slice(0, 20));
                    setError(null);
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleJoinGame()}
                  placeholder="Твоє ім'я"
                  autoFocus
                  maxLength={20}
                  className="mt-6 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-center text-xl font-extrabold outline-none focus:border-purple-400/60 focus:bg-white/10"
                />
                {error && <p className="mt-2 text-sm font-bold text-red-400">{error}</p>}
                <button
                  onClick={handleJoinGame}
                  disabled={loading}
                  className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 py-4 text-lg font-extrabold shadow-lg transition hover:brightness-110 active:scale-95 disabled:opacity-50"
                >
                  {loading ? <Loader2 size={22} className="animate-spin" /> : 'Грати!'}
                </button>
              </>
            )}
          </div>
        </main>
      </div>
    );
  }

  if (!room || !quiz || !player) return null;

  // ---- Lobby ----
  if (phase === 'lobby') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-4 text-center">
        <div className="animate-float-up">
          <div className="mb-4 grid h-20 w-20 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-2xl">
            <Check size={40} className="text-white" />
          </div>
          <h1 className="text-2xl font-black">Готово, {player.nickname}!</h1>
          <p className="mt-2 text-slate-400">Очікуємо початку гри…</p>
          <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 px-8 py-4">
            <p className="text-xs text-slate-400">Код кімнати</p>
            <p className="text-3xl font-black tracking-[0.3em] text-purple-300">{room.code}</p>
          </div>
          <div className="mt-4 text-sm text-slate-400">
            <Users size={15} className="mr-1 inline" /> {players.length} гравців у кімнаті
          </div>
        </div>
      </div>
    );
  }

  // ---- Finished ----
  if (phase === 'finished') {
    const sorted = [...players].sort((a, b) => b.score - a.score);
    const myRank = sorted.findIndex((p) => p.id === player.id) + 1;
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-4">
        <div className="w-full max-w-md text-center animate-float-up">
          <div className="mb-4 grid h-24 w-24 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 shadow-2xl shadow-orange-500/40">
            <Trophy size={48} className="text-white" />
          </div>
          <h1 className="text-3xl font-black">Гру завершено!</h1>
          <p className="mt-1 text-slate-400">{quiz.title}</p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="text-xs text-slate-400">Твоє місце</p>
              <p className="text-3xl font-black text-amber-300">#{myRank}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="text-xs text-slate-400">Твій бал</p>
              <p className="text-3xl font-black text-emerald-300">{player.score}</p>
            </div>
          </div>

          <div className="mt-4 max-h-48 space-y-1 overflow-y-auto scroll-thin">
            {sorted.slice(0, 10).map((p, i) => (
              <div
                key={p.id}
                className={`flex items-center gap-3 rounded-xl p-2 text-sm ${
                  p.id === player.id ? 'bg-purple-500/20 font-bold' : 'bg-white/5'
                }`}
              >
                <span className="w-6 text-center font-black">{i + 1}</span>
                <span className="flex-1 text-left">{p.nickname}</span>
                <span className="text-amber-300">{p.score}</span>
              </div>
            ))}
          </div>

          <button
            onClick={onHome}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 py-3 font-extrabold transition hover:brightness-110 active:scale-95"
          >
            <LogOut size={18} /> Вийти
          </button>
        </div>
      </div>
    );
  }

  // ---- Question / Reveal ----
  const q = quiz.questions[room.current_index];
  if (!q) return null;

  const timePct = Math.max(0, (timeLeft / q.timeLimit) * 100);
  const myAnswer = player.answers.find((a) => a.questionId === q.id);
  const hasAnswered = !!myAnswer || answeredRef.current;

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      <header className="flex items-center justify-between px-4 py-3">
        <div className="rounded-xl bg-white/5 px-3 py-1.5 text-sm font-bold">
          {room.current_index + 1} / {quiz.questions.length}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-slate-300">{player.nickname}</span>
          <span className="rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-3 py-1.5 text-sm font-extrabold">
            {player.score}
          </span>
        </div>
      </header>

      {phase === 'question' && (
        <div className="px-4">
          <div className="flex items-center gap-2">
            <Clock size={16} className={timeLeft <= 5 ? 'text-red-400' : 'text-slate-400'} />
            <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-white/10">
              <div
                className={`absolute inset-y-0 left-0 rounded-full transition-all duration-1000 ease-linear ${
                  timeLeft <= 5 ? 'bg-red-500' : 'bg-gradient-to-r from-emerald-400 to-green-500'
                }`}
                style={{ width: `${timePct}%` }}
              />
            </div>
            <span className={`w-8 text-right text-sm font-extrabold ${timeLeft <= 5 ? 'text-red-400' : ''}`}>
              {timeLeft}
            </span>
          </div>
        </div>
      )}

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div key={`${q.id}-${phase}`} className="w-full max-w-3xl animate-fade-in">
          {q.imageUrl && (
            <div className="mb-4 overflow-hidden rounded-3xl border border-white/10">
              <img src={q.imageUrl} alt="" className="max-h-48 w-full object-contain bg-black/30" />
            </div>
          )}
          <div className="mb-5 rounded-3xl border border-white/10 bg-white/5 p-5 text-center text-xl font-extrabold sm:text-2xl">
            {q.prompt || `Запитання ${room.current_index + 1}`}
          </div>

          {phase === 'question' && hasAnswered ? (
            <div className="flex flex-col items-center gap-3 py-10 animate-fade-in">
              <div className="grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-green-600 shadow-2xl animate-pop">
                <Check size={40} className="text-white" />
              </div>
              <p className="text-lg font-extrabold">Відповідь надіслано!</p>
              <p className="text-sm text-slate-400">Чекаємо решту гравців…</p>
            </div>
          ) : phase === 'question' ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {q.options.map((opt, i) => (
                <button
                  key={opt.id}
                  onClick={() => handleAnswer(opt.id)}
                  disabled={hasAnswered}
                  className={`flex items-center gap-3 rounded-2xl ${OPTION_COLORS[i % OPTION_COLORS.length]} p-4 text-left text-base font-bold text-white transition active:scale-[0.98] disabled:opacity-60`}
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/20 text-sm">
                    {i + 1}
                  </span>
                  <span className="flex-1">{opt.text || `Варіант ${i + 1}`}</span>
                </button>
              ))}
            </div>
          ) : (
            // reveal
            <div className="grid gap-3 sm:grid-cols-2">
              {q.options.map((opt, i) => {
                const isCorrect = opt.id === q.correctOptionId;
                const isMine = myAnswer?.optionId === opt.id;
                let cls = 'bg-white/5 text-slate-400';
                if (isCorrect) cls = 'bg-emerald-500 text-white ring-4 ring-emerald-300/50 animate-pop';
                else if (isMine) cls = 'bg-red-500/80 text-white animate-shake';
                else if (phase === 'reveal') cls = `${OPTION_COLORS[i % OPTION_COLORS.length]} text-white opacity-50`;
                return (
                  <div
                    key={opt.id}
                    className={`flex items-center gap-3 rounded-2xl p-4 text-left text-base font-bold ${cls}`}
                  >
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/20 text-sm">
                      {isCorrect ? <Check size={18} /> : isMine ? <X size={18} /> : i + 1}
                    </span>
                    <span className="flex-1">{opt.text || `Варіант ${i + 1}`}</span>
                  </div>
                );
              })}
            </div>
          )}

          {phase === 'reveal' && (
            <div className="mt-6 text-center">
              {myAnswer?.correct ? (
                <p className="text-lg font-extrabold text-emerald-400">
                  Правильно! +{myAnswer.points} балів
                </p>
              ) : (
                <p className="text-lg font-extrabold text-red-400">Неправильно :(</p>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
