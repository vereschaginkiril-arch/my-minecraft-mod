import { useEffect, useState, useRef, useCallback } from 'react';
import { ArrowLeft, Check, X, Clock, Trophy, RotateCcw, Home, Loader2 } from 'lucide-react';
import { fetchQuiz } from '@/lib/db';
import type { Quiz, Question } from '@/lib/types';

interface SoloProps {
  quizId: string;
  onBack: () => void;
  onHome: () => void;
}

const OPTION_COLORS = [
  'bg-rose-500',
  'bg-sky-500',
  'bg-amber-500',
  'bg-emerald-500',
  'bg-violet-500',
  'bg-pink-500',
];

type Phase = 'playing' | 'results';

export function Solo({ quizId, onBack, onHome }: SoloProps) {
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<{ questionId: string; correct: boolean; points: number }[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [phase, setPhase] = useState<Phase>('playing');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef(0);

  const load = useCallback(async () => {
    try {
      const q = await fetchQuiz(quizId);
      setQuiz(q);
      if (q && q.questions.length > 0) {
        setTimeLeft(q.questions[0].timeLimit);
        startTimeRef.current = Date.now();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [quizId]);

  useEffect(() => {
    load();
  }, [load]);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const reveal = useCallback(
    (optionId: string | null) => {
      if (!quiz || revealed) return;
      stopTimer();
      const q = quiz.questions[idx];
      const correct = optionId === q.correctOptionId;
      const elapsedMs = Date.now() - startTimeRef.current;
      let points = 0;
      if (correct) {
        // Kahoot-like scoring: base 1000 * (remaining/total), min 100
        const remaining = Math.max(0, timeLeft);
        points = Math.round(100 + (1000 * remaining) / q.timeLimit);
      }
      setSelected(optionId);
      setRevealed(true);
      setScore((s) => s + points);
      setAnswers((a) => [...a, { questionId: q.id, correct, points }]);
    },
    [quiz, idx, revealed, stopTimer, timeLeft],
  );

  // timer
  useEffect(() => {
    if (!quiz || revealed || phase !== 'playing') return;
    stopTimer();
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          stopTimer();
          reveal(null);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return stopTimer;
  }, [quiz, idx, revealed, phase, stopTimer, reveal]);

  function next() {
    if (!quiz) return;
    const nextIdx = idx + 1;
    if (nextIdx >= quiz.questions.length) {
      setPhase('results');
      return;
    }
    setIdx(nextIdx);
    setSelected(null);
    setRevealed(false);
    setTimeLeft(quiz.questions[nextIdx].timeLimit);
    startTimeRef.current = Date.now();
  }

  function restart() {
    setIdx(0);
    setSelected(null);
    setRevealed(false);
    setScore(0);
    setAnswers([]);
    setPhase('playing');
    if (quiz) {
      setTimeLeft(quiz.questions[0].timeLimit);
      startTimeRef.current = Date.now();
    }
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900">
        <Loader2 className="animate-spin text-purple-400" size={32} />
      </div>
    );
  }

  if (!quiz || quiz.questions.length === 0) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900 text-center">
        <div>
          <p className="text-slate-400">У цій вікторині ще немає запитань.</p>
          <button onClick={onBack} className="mt-4 rounded-xl bg-white/10 px-4 py-2 font-bold">
            Назад
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'results') {
    return <SoloResults quiz={quiz} score={score} answers={answers} onRestart={restart} onHome={onHome} />;
  }

  const q: Question = quiz.questions[idx];
  const timePct = Math.max(0, (timeLeft / q.timeLimit) * 100);

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      <header className="flex items-center justify-between px-4 py-4">
        <button
          onClick={onBack}
          className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
        >
          <ArrowLeft size={18} />
        </button>
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-white/5 px-3 py-1.5 text-sm font-bold">
            {idx + 1} / {quiz.questions.length}
          </div>
          <div className="rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-3 py-1.5 text-sm font-extrabold shadow-lg shadow-orange-500/20">
            {score} балів
          </div>
        </div>
      </header>

      {/* Timer bar */}
      <div className="px-4">
        <div className="flex items-center gap-2">
          <Clock size={16} className={timeLeft <= 5 ? 'text-red-400' : 'text-slate-400'} />
          <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-white/10">
            <div
              className={`absolute inset-y-0 left-0 rounded-full transition-all duration-1000 ease-linear ${
                timeLeft <= 5 ? 'bg-red-500' : 'bg-gradient-to-r from-emerald-400 to-green-500'
              }`}
              style={{ width: `${timePct}%` }}
            />
          </div>
          <span className={`w-8 text-right text-sm font-extrabold ${timeLeft <= 5 ? 'text-red-400' : ''}`}>
            {timeLeft}
          </span>
        </div>
      </div>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div key={q.id} className="w-full max-w-3xl animate-fade-in">
          {q.imageUrl && (
            <div className="mb-5 overflow-hidden rounded-3xl border border-white/10">
              <img src={q.imageUrl} alt="" className="max-h-60 w-full object-contain bg-black/30" />
            </div>
          )}
          <div className="mb-6 rounded-3xl border border-white/10 bg-white/5 p-6 text-center text-xl font-extrabold sm:text-2xl">
            {q.prompt || `Запитання ${idx + 1}`}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {q.options.map((opt, i) => {
              const isCorrect = opt.id === q.correctOptionId;
              const isSelected = opt.id === selected;
              let cls = `${OPTION_COLORS[i % OPTION_COLORS.length]} text-white`;
              if (revealed) {
                if (isCorrect) cls = 'bg-emerald-500 text-white ring-4 ring-emerald-300/50 animate-pop';
                else if (isSelected) cls = 'bg-red-500/80 text-white animate-shake';
                else cls = 'bg-white/5 text-slate-400';
              }
              return (
                <button
                  key={opt.id}
                  disabled={revealed}
                  onClick={() => reveal(opt.id)}
                  className={`flex items-center gap-3 rounded-2xl p-4 text-left text-base font-bold transition active:scale-[0.98] disabled:active:scale-100 ${cls}`}
                >
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-black/20 text-sm">
                    {revealed && isCorrect ? <Check size={18} /> : revealed && isSelected ? <X size={18} /> : i + 1}
                  </span>
                  <span className="flex-1">{opt.text || `Варіант ${i + 1}`}</span>
                </button>
              );
            })}
          </div>

          {revealed && (
            <div className="mt-6 flex justify-center animate-fade-in">
              <button
                onClick={next}
                className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-8 py-3 font-extrabold shadow-lg shadow-purple-500/30 transition hover:brightness-110 active:scale-95"
              >
                {idx + 1 >= quiz.questions.length ? 'Результати' : 'Наступне →'}
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function SoloResults({
  quiz,
  score,
  answers,
  onRestart,
  onHome,
}: {
  quiz: Quiz;
  score: number;
  answers: { questionId: string; correct: boolean; points: number }[];
  onRestart: () => void;
  onHome: () => void;
}) {
  const correctCount = answers.filter((a) => a.correct).length;
  const total = quiz.questions.length;
  const pct = total ? Math.round((correctCount / total) * 100) : 0;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-4">
      <Confetti show={pct >= 60} />
      <div className="w-full max-w-md animate-float-up text-center">
        <div className="mb-4 grid h-24 w-24 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 shadow-2xl shadow-orange-500/40">
          <Trophy size={48} className="text-white" />
        </div>
        <h1 className="text-3xl font-black">Гру завершено!</h1>
        <div className="my-6 grid grid-cols-3 gap-3">
          <ResultStat label="Бали" value={score} color="from-amber-500 to-orange-600" />
          <ResultStat label="Правильно" value={`${correctCount}/${total}`} color="from-emerald-500 to-green-600" />
          <ResultStat label="Точність" value={`${pct}%`} color="from-sky-500 to-blue-600" />
        </div>
        <div className="flex gap-3">
          <button
            onClick={onRestart}
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 py-3 font-extrabold shadow-lg transition hover:brightness-110 active:scale-95"
          >
            <RotateCcw size={18} /> Ще раз
          </button>
          <button
            onClick={onHome}
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 py-3 font-bold transition hover:bg-white/10"
          >
            <Home size={18} /> На головну
          </button>
        </div>
      </div>
    </div>
  );
}

function ResultStat({ label, value, color }: { label: string; value: string | number; color: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className={`mb-1 inline-block rounded-md bg-gradient-to-br ${color} px-2 py-0.5 text-[10px] font-extrabold`}>
        {label}
      </div>
      <div className="text-xl font-black">{value}</div>
    </div>
  );
}

export function Confetti({ show }: { show: boolean }) {
  if (!show) return null;
  const colors = ['#e21b3c', '#1368ce', '#d89e00', '#26890c', '#8b5cf6', '#ec4899'];
  return (
    <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
      {Array.from({ length: 60 }).map((_, i) => (
        <div
          key={i}
          className="confetti-piece absolute top-0"
          style={{
            left: `${Math.random() * 100}%`,
            width: `${6 + Math.random() * 6}px`,
            height: `${10 + Math.random() * 10}px`,
            background: colors[i % colors.length],
            animationDuration: `${2 + Math.random() * 2}s`,
            animationDelay: `${Math.random() * 0.5}s`,
            borderRadius: Math.random() > 0.5 ? '50%' : '2px',
          }}
        />
      ))}
    </div>
  );
}
