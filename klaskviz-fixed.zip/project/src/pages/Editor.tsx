import { useEffect, useRef, useState, useCallback } from 'react';
import {
  ArrowLeft,
  Plus,
  Trash2,
  Copy,
  GripVertical,
  Type,
  Image as ImageIcon,
  Check,
  Clock,
  X,
  Upload,
  Loader2,
  Settings,
  Save,
} from 'lucide-react';
import { fetchQuiz, saveQuiz, createQuiz, uploadQuestionImage, deleteQuestionImage } from '@/lib/db';
import { emptyQuestion } from '@/lib/types';
import type { Question, Quiz } from '@/lib/types';
import { Modal } from '@/components/ui';

interface EditorProps {
  quizId: string;
  onBack: () => void;
  onDone: (quizId: string) => void;
}

const TIME_OPTIONS = [10, 20, 30, 45, 60, 90, 120];

const OPTION_COLORS = [
  { bg: 'bg-rose-500', ring: 'ring-rose-400', text: 'text-rose-50' },
  { bg: 'bg-sky-500', ring: 'ring-sky-400', text: 'text-sky-50' },
  { bg: 'bg-amber-500', ring: 'ring-amber-400', text: 'text-amber-50' },
  { bg: 'bg-emerald-500', ring: 'ring-emerald-400', text: 'text-emerald-50' },
];

export function Editor({ quizId, onBack, onDone }: EditorProps) {
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [title, setTitle] = useState('');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [dirty, setDirty] = useState(false);
  const dragIdx = useRef<number | null>(null);
  const dragOverIdx = useRef<number | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async () => {
    try {
      const q = await fetchQuiz(quizId);
      if (!q) {
        // maybe it's a new quiz id that doesn't exist — create
        const created = await createQuiz('Без назви');
        setQuiz(created);
        setTitle(created.title);
      } else {
        setQuiz(q);
        setTitle(q.title);
      }
    } catch (e) {
      console.error('Editor load failed', e);
    } finally {
      setLoading(false);
    }
  }, [quizId]);

  useEffect(() => {
    load();
  }, [load]);

  // autosave (debounced) whenever quiz content changes
  const scheduleSave = useCallback(
    (q: Quiz) => {
      setDirty(true);
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(async () => {
        setSaving(true);
        try {
          await saveQuiz(q.id, q.title, q.questions);
          setSavedAt(new Date().toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }));
          setDirty(false);
        } catch (e) {
          console.error('Autosave failed', e);
        } finally {
          setSaving(false);
        }
      }, 900);
    },
    [],
  );

  function updateQuestions(questions: Question[]) {
    if (!quiz) return;
    const next = { ...quiz, questions };
    setQuiz(next);
    scheduleSave(next);
  }

  function updateTitle(t: string) {
    if (!quiz) return;
    setTitle(t);
    const next = { ...quiz, title: t };
    setQuiz(next);
    scheduleSave(next);
  }

  function addQuestion() {
    if (!quiz) return;
    const q = emptyQuestion();
    updateQuestions([...quiz.questions, q]);
    setCurrentIdx(quiz.questions.length);
  }

  function deleteQuestion(idx: number) {
    if (!quiz) return;
    const qs = quiz.questions.filter((_, i) => i !== idx);
    updateQuestions(qs);
    setCurrentIdx((c) => Math.max(0, Math.min(c, qs.length - 1)));
  }

  function duplicateQuestion(idx: number) {
    if (!quiz) return;
    const orig = quiz.questions[idx];
    const copy: Question = {
      ...JSON.parse(JSON.stringify(orig)),
      id: crypto.randomUUID(),
      options: orig.options.map((o) => ({ ...o, id: crypto.randomUUID() })),
    };
    // fix correctOptionId to match new option ids
    const oldIdx = orig.options.findIndex((o) => o.id === orig.correctOptionId);
    if (oldIdx >= 0) copy.correctOptionId = copy.options[oldIdx].id;
    const qs = [...quiz.questions];
    qs.splice(idx + 1, 0, copy);
    updateQuestions(qs);
    setCurrentIdx(idx + 1);
  }

  function patchCurrent(patch: Partial<Question>) {
    if (!quiz) return;
    const qs = quiz.questions.map((q, i) => (i === currentIdx ? { ...q, ...patch } : q));
    updateQuestions(qs);
  }

  function patchOption(optIdx: number, text: string) {
    if (!quiz) return;
    const q = quiz.questions[currentIdx];
    if (!q) return;
    const options = q.options.map((o, i) => (i === optIdx ? { ...o, text } : o));
    patchCurrent({ options });
  }

  function addOption() {
    if (!quiz) return;
    const q = quiz.questions[currentIdx];
    if (!q || q.options.length >= 6) return;
    patchCurrent({ options: [...q.options, { id: crypto.randomUUID(), text: '' }] });
  }

  function removeOption(optIdx: number) {
    if (!quiz) return;
    const q = quiz.questions[currentIdx];
    if (!q || q.options.length <= 2) return;
    const newOpts = q.options.filter((_, i) => i !== optIdx);
    let correctId = q.correctOptionId;
    if (q.correctOptionId === q.options[optIdx].id) correctId = newOpts[0].id;
    patchCurrent({ options: newOpts, correctOptionId: correctId });
  }

  // drag reorder
  function onDragStart(i: number) {
    dragIdx.current = i;
  }
  function onDragOver(i: number, e: React.DragEvent) {
    e.preventDefault();
    dragOverIdx.current = i;
  }
  function onDrop() {
    if (!quiz) return;
    const from = dragIdx.current;
    const to = dragOverIdx.current;
    if (from === null || to === null || from === to) {
      dragIdx.current = null;
      dragOverIdx.current = null;
      return;
    }
    const qs = [...quiz.questions];
    const [moved] = qs.splice(from, 1);
    qs.splice(to, 0, moved);
    updateQuestions(qs);
    setCurrentIdx(to);
    dragIdx.current = null;
    dragOverIdx.current = null;
  }

  async function handleImageUpload(file: File) {
    if (!quiz) return;
    const q = quiz.questions[currentIdx];
    if (!q) return;
    try {
      // delete old image if present
      if (q.imagePath) await deleteQuestionImage(q.imagePath);
      const { path, url } = await uploadQuestionImage(file, quiz.id);
      patchCurrent({ imagePath: path, imageUrl: url });
    } catch (e) {
      console.error('Image upload failed', e);
      alert('Не вдалося завантажити фото. Спробуйте ще раз.');
    }
  }

  async function removeImage() {
    if (!quiz) return;
    const q = quiz.questions[currentIdx];
    if (!q || !q.imagePath) return;
    try {
      await deleteQuestionImage(q.imagePath);
      patchCurrent({ imagePath: null, imageUrl: null });
    } catch (e) {
      console.error(e);
    }
  }

  async function handleDone() {
    if (!quiz) return;
    setSaving(true);
    try {
      await saveQuiz(quiz.id, quiz.title, quiz.questions);
      setDirty(false);
      setSaving(false);
      onDone(quiz.id);
    } catch (e) {
      console.error(e);
      setSaving(false);
      alert('Не вдалося зберегти. Перевірте зʼєднання.');
    }
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900">
        <Loader2 className="animate-spin text-purple-400" size={32} />
      </div>
    );
  }

  const current = quiz?.questions[currentIdx] ?? null;

  return (
    <div className="flex h-screen flex-col bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950">
      {/* Top bar */}
      <header className="z-20 flex items-center justify-between gap-3 border-b border-white/10 bg-slate-900/80 px-4 py-3 backdrop-blur-xl">
        <div className="flex min-w-0 items-center gap-2">
          <button
            onClick={onBack}
            className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
            title="Назад"
          >
            <ArrowLeft size={18} />
          </button>
          <input
            value={title}
            onChange={(e) => updateTitle(e.target.value)}
            placeholder="Назва вікторини"
            className="w-40 truncate rounded-xl border border-transparent bg-transparent px-2 py-2 text-base font-extrabold outline-none transition focus:border-white/15 focus:bg-white/5 sm:w-64"
          />
        </div>

        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-1.5 text-xs text-slate-400 sm:flex">
            {saving ? (
              <>
                <Loader2 size={13} className="animate-spin" /> Збереження…
              </>
            ) : dirty ? (
              <span className="text-amber-400">Незбережено</span>
            ) : savedAt ? (
              <>
                <Check size={13} className="text-emerald-400" /> Збережено о {savedAt}
              </>
            ) : null}
          </div>
          <button
            onClick={() => setShowSettings(true)}
            className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
            title="Налаштування"
          >
            <Settings size={18} />
          </button>
          <button
            onClick={handleDone}
            disabled={saving}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 px-4 py-2.5 text-sm font-extrabold shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-60"
          >
            <Save size={16} /> Готово
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left slide list */}
        <aside className="flex w-16 flex-col border-r border-white/10 bg-slate-950/40 sm:w-60">
          <div className="flex-1 overflow-y-auto scroll-thin p-2">
            <div className="flex flex-col gap-2">
              {quiz?.questions.map((q, i) => (
                <div
                  key={q.id}
                  draggable
                  onDragStart={() => onDragStart(i)}
                  onDragOver={(e) => onDragOver(i, e)}
                  onDrop={onDrop}
                  onClick={() => setCurrentIdx(i)}
                  className={`group relative cursor-pointer rounded-xl border p-2 transition ${
                    i === currentIdx
                      ? 'border-purple-400/60 bg-purple-500/15'
                      : 'border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`grid h-6 w-6 shrink-0 place-items-center rounded-md text-xs font-extrabold ${
                        i === currentIdx ? 'bg-purple-500 text-white' : 'bg-white/10 text-slate-300'
                      }`}
                    >
                      {i + 1}
                    </span>
                    <div className="hidden min-w-0 flex-1 sm:block">
                      <p className="truncate text-xs font-semibold">
                        {q.prompt || `Запитання ${i + 1}`}
                      </p>
                      <p className="flex items-center gap-1 text-[10px] text-slate-400">
                        {q.type === 'image' ? <ImageIcon size={10} /> : <Type size={10} />}
                        {q.options.length} відповідей
                      </p>
                    </div>
                    {q.imageUrl && (
                      <img
                        src={q.imageUrl}
                        alt=""
                        className="hidden h-8 w-8 rounded object-cover sm:block"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-white/10 p-2">
            <button
              onClick={addQuestion}
              className="flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-white/15 py-3 font-bold text-slate-300 transition hover:border-purple-400/60 hover:bg-purple-500/10 hover:text-white"
            >
              <Plus size={20} />
              <span className="hidden sm:inline">Додати</span>
            </button>
          </div>
        </aside>

        {/* Center working area */}
        <main className="flex flex-1 flex-col overflow-y-auto scroll-thin">
          {!current ? (
            <EmptyEditor onAdd={addQuestion} />
          ) : (
            <div className="mx-auto w-full max-w-3xl flex-1 p-4 sm:p-8">
              {/* type chooser */}
              <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-slate-400">Тип запитання</span>
                  <div className="flex gap-1 rounded-xl bg-white/5 p-1">
                    <button
                      onClick={() => patchCurrent({ type: 'text' })}
                      className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-bold transition ${
                        current.type === 'text' ? 'bg-purple-500 text-white' : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      <Type size={15} /> Текст
                    </button>
                    <button
                      onClick={() => patchCurrent({ type: 'image' })}
                      className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-bold transition ${
                        current.type === 'image' ? 'bg-purple-500 text-white' : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      <ImageIcon size={15} /> Фото
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => duplicateQuestion(currentIdx)}
                    className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm font-bold transition hover:bg-white/10"
                    title="Копіювати"
                  >
                    <Copy size={14} /> <span className="hidden sm:inline">Копіювати</span>
                  </button>
                  <button
                    onClick={() => deleteQuestion(currentIdx)}
                    className="flex items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-sm font-bold text-red-300 transition hover:bg-red-500/20"
                    title="Видалити"
                  >
                    <Trash2 size={14} /> <span className="hidden sm:inline">Видалити</span>
                  </button>
                </div>
              </div>

              {/* Image area */}
              {current.type === 'image' && (
                <ImageZone
                  question={current}
                  onUpload={handleImageUpload}
                  onRemove={removeImage}
                />
              )}

              {/* Prompt */}
              <div className="mb-6">
                <label className="mb-2 block text-sm font-bold text-slate-300">Запитання</label>
                <textarea
                  value={current.prompt}
                  onChange={(e) => patchCurrent({ prompt: e.target.value })}
                  placeholder="Введіть запитання…"
                  rows={2}
                  className="w-full resize-none rounded-2xl border border-white/10 bg-white/5 p-4 text-base font-semibold outline-none transition focus:border-purple-400/60 focus:bg-white/10"
                />
              </div>

              {/* Options */}
              <div className="mb-6">
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-bold text-slate-300">
                    Відповіді{' '}
                    <span className="text-slate-500">(натисни на кружечок — правильна)</span>
                  </label>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {current.options.map((opt, i) => {
                    const color = OPTION_COLORS[i % OPTION_COLORS.length];
                    const isCorrect = current.correctOptionId === opt.id;
                    return (
                      <div
                        key={opt.id}
                        className={`flex items-center gap-2 rounded-2xl border p-2 pl-3 transition ${
                          isCorrect
                            ? `border-transparent ${color.bg} ${color.text} ring-2 ${color.ring}`
                            : 'border-white/10 bg-white/5'
                        }`}
                      >
                        <button
                          onClick={() => patchCurrent({ correctOptionId: opt.id })}
                          className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 transition ${
                            isCorrect
                              ? 'border-white bg-white/20'
                              : 'border-white/30 hover:border-white/60'
                          }`}
                          title="Позначити правильною"
                        >
                          {isCorrect && <Check size={16} />}
                        </button>
                        <input
                          value={opt.text}
                          onChange={(e) => patchOption(i, e.target.value)}
                          placeholder={`Варіант ${i + 1}`}
                          className={`min-w-0 flex-1 bg-transparent text-sm font-semibold outline-none ${
                            isCorrect ? 'placeholder-white/60' : 'placeholder-slate-500'
                          }`}
                        />
                        {current.options.length > 2 && (
                          <button
                            onClick={() => removeOption(i)}
                            className="shrink-0 rounded-lg p-1 opacity-60 transition hover:bg-black/20 hover:opacity-100"
                          >
                            <X size={14} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
                {current.options.length < 6 && (
                  <button
                    onClick={addOption}
                    className="mt-3 flex items-center gap-1.5 text-sm font-bold text-purple-300 transition hover:text-purple-200"
                  >
                    <Plus size={16} /> Додати варіант
                  </button>
                )}
              </div>

              {/* Time limit */}
              <div className="mb-4">
                <label className="mb-2 flex items-center gap-2 text-sm font-bold text-slate-300">
                  <Clock size={15} /> Час на відповідь
                </label>
                <div className="flex flex-wrap gap-2">
                  {TIME_OPTIONS.map((t) => (
                    <button
                      key={t}
                      onClick={() => patchCurrent({ timeLimit: t })}
                      className={`rounded-xl px-4 py-2 text-sm font-extrabold transition ${
                        current.timeLimit === t
                          ? 'bg-purple-500 text-white'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      {t} сек
                    </button>
                  ))}
                </div>
              </div>

              {/* Slide number footer */}
              <div className="mt-8 flex items-center justify-between border-t border-white/10 pt-4 text-sm text-slate-400">
                <span>
                  Слайд {currentIdx + 1} з {quiz?.questions.length}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                    disabled={currentIdx === 0}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 font-bold transition hover:bg-white/10 disabled:opacity-30"
                  >
                    ← Попереднє
                  </button>
                  <button
                    onClick={() => setCurrentIdx((i) => Math.min((quiz?.questions.length ?? 1) - 1, i + 1))}
                    disabled={currentIdx === (quiz?.questions.length ?? 1) - 1}
                    className="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 font-bold transition hover:bg-white/10 disabled:opacity-30"
                  >
                    Наступне →
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      <Modal open={showSettings} onClose={() => setShowSettings(false)} title="Налаштування вікторини">
        <div className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-bold text-slate-300">Назва</label>
            <input
              value={title}
              onChange={(e) => updateTitle(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 font-semibold outline-none focus:border-purple-400/60"
            />
          </div>
          <div className="rounded-xl bg-white/5 p-4 text-sm text-slate-400">
            <div className="mb-1 flex justify-between">
              <span>Запитань</span>
              <span className="font-bold text-white">{quiz?.questions.length ?? 0}</span>
            </div>
            <div className="flex justify-between">
              <span>Сумарний час</span>
              <span className="font-bold text-white">
                {quiz?.questions.reduce((s, q) => s + q.timeLimit, 0) ?? 0} сек
              </span>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function ImageZone({
  question,
  onUpload,
  onRemove,
}: {
  question: Question;
  onUpload: (file: File) => void;
  onRemove: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      await onUpload(file);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  }

  if (question.imageUrl) {
    return (
      <div className="relative mb-6 overflow-hidden rounded-3xl border border-white/10 bg-black/30">
        <img src={question.imageUrl} alt="Запитання" className="max-h-72 w-full object-contain" />
        <button
          onClick={onRemove}
          className="absolute right-3 top-3 rounded-xl bg-black/60 p-2 backdrop-blur transition hover:bg-red-500/80"
          title="Видалити фото"
        >
          <Trash2 size={16} />
        </button>
        <button
          onClick={() => inputRef.current?.click()}
          className="absolute bottom-3 right-3 rounded-xl bg-black/60 px-3 py-2 text-xs font-bold backdrop-blur transition hover:bg-black/80"
        >
          Замінити
        </button>
        <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      </div>
    );
  }

  return (
    <div
      className="mb-6 flex flex-col items-center justify-center rounded-3xl border-2 border-dashed border-white/15 bg-white/5 p-8 text-center transition hover:border-purple-400/40 hover:bg-purple-500/5"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        const file = e.dataTransfer.files?.[0];
        if (file && file.type.startsWith('image/')) {
          setUploading(true);
          Promise.resolve(onUpload(file)).finally(() => setUploading(false));
        }
      }}
    >
      <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      {uploading ? (
        <Loader2 className="animate-spin text-purple-400" size={36} />
      ) : (
        <>
          <div className="mb-3 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-fuchsia-500/30 to-purple-600/30">
            <ImageIcon size={32} className="text-purple-300" />
          </div>
          <p className="font-bold">Перетягни фото сюди</p>
          <p className="mb-4 text-sm text-slate-400">або обери з пристрою</p>
          <button
            onClick={() => inputRef.current?.click()}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-5 py-2.5 font-bold shadow-lg transition hover:brightness-110 active:scale-95"
          >
            <Upload size={18} /> Завантажити фото
          </button>
        </>
      )}
    </div>
  );
}

function EmptyEditor({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
      <div className="mb-4 grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-fuchsia-500/30 to-purple-600/30">
        <Type size={36} className="text-purple-300" />
      </div>
      <h2 className="text-2xl font-black">Створи перше запитання</h2>
      <p className="mt-2 max-w-sm text-slate-400">
        Додай текст або фото, чотири варіанти відповідей і познач правильну.
      </p>
      <button
        onClick={onAdd}
        className="mt-6 flex items-center gap-2 rounded-xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-6 py-3 font-extrabold shadow-lg shadow-purple-500/30 transition hover:brightness-110 active:scale-95"
      >
        <Plus size={20} /> Додати запитання
      </button>
    </div>
  );
}
