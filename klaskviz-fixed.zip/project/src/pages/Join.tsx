import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, DoorOpen, Loader2, ArrowRight } from 'lucide-react';
import { fetchRoomByCode } from '@/lib/db';

interface JoinProps {
  prefillCode?: string;
  onBack: () => void;
  onJoinRoom: (roomId: string) => void;
}

export function Join({ prefillCode, onBack, onJoinRoom }: JoinProps) {
  const [code, setCode] = useState(prefillCode ?? '');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const autoJoinRef = useRef(false);

  async function handleJoin(rawCode?: string) {
    const c = (rawCode ?? code).trim().toUpperCase();
    if (c.length < 4) {
      setError('Введи код із 6 символів');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await fetchRoomByCode(c);
      if (!data) {
        setError('Кімнату з таким кодом не знайдено');
        setLoading(false);
        return;
      }
      onJoinRoom(data.room.id);
    } catch (e) {
      console.error(e);
      setError('Не вдалося знайти кімнату. Спробуй ще раз.');
      setLoading(false);
    }
  }

  // auto-join if code came from a shared link
  useEffect(() => {
    if (prefillCode && prefillCode.length >= 4 && !autoJoinRef.current) {
      autoJoinRef.current = true;
      setCode(prefillCode);
      handleJoin(prefillCode);
    }
  }, [prefillCode]);

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      <header className="flex items-center gap-3 px-4 py-4">
        <button
          onClick={onBack}
          className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
        >
          <ArrowLeft size={18} />
        </button>
        <span className="font-bold text-slate-300">Приєднатись до гри</span>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center px-4">
        <div className="w-full max-w-sm text-center">
          <div className="mb-6 grid h-20 w-20 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 shadow-2xl shadow-orange-500/40">
            <DoorOpen size={40} className="text-white" />
          </div>
          <h1 className="text-2xl font-black">Введи код кімнати</h1>
          <p className="mt-1 text-sm text-slate-400">Код складається з 6 символів — його дає ведучий</p>

          <div className="mt-8">
            <input
              value={code}
              onChange={(e) => {
                setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6));
                setError(null);
              }}
              onKeyDown={(e) => e.key === 'Enter' && handleJoin()}
              placeholder="XXXXXX"
              autoFocus
              maxLength={6}
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-center text-3xl font-black tracking-[0.4em] outline-none transition focus:border-amber-400/60 focus:bg-white/10"
            />
            {error && <p className="mt-2 text-sm font-bold text-red-400">{error}</p>}
          </div>

          <button
            onClick={() => handleJoin()}
            disabled={loading || code.length < 4}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 py-4 text-lg font-extrabold shadow-lg shadow-orange-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-40"
          >
            {loading ? <Loader2 size={22} className="animate-spin" /> : <ArrowRight size={22} />}
            Грати
          </button>
        </div>
      </main>
    </div>
  );
}
