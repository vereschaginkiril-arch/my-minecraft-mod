import { useEffect, useState, useRef, useCallback } from 'react';
import {
  ArrowLeft,
  Users,
  Copy,
  Check,
  Play,
  ChevronRight,
  ChevronLeft,
  Trophy,
  Loader2,
  BarChart3,
  RotateCcw,
  Home,
  Share2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { fetchRoomWithQuiz, updateRoom, fetchPlayers } from '@/lib/db';
import type { Room, Quiz, Player } from '@/lib/types';
import { Confetti } from './Solo';

interface HostProps {
  roomId: string;
  onBack: () => void;
  onHome: () => void;
}

type HostPhase = 'lobby' | 'question' | 'results' | 'final';

export function Host({ roomId, onBack, onHome }: HostProps) {
  const [room, setRoom] = useState<Room | null>(null);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [phase, setPhase] = useState<HostPhase>('lobby');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const playersRef = useRef<Player[]>([]);

  const refreshPlayers = useCallback(async () => {
    try {
      const ps = await fetchPlayers(roomId);
      playersRef.current = ps;
      setPlayers(ps);
    } catch (e) {
      console.error(e);
    }
  }, [roomId]);

  const load = useCallback(async () => {
    try {
      const data = await fetchRoomWithQuiz(roomId);
      if (!data) return;
      setRoom(data.room);
      setQuiz(data.quiz);
      await refreshPlayers();
      if (data.room.status === 'playing') {
        setPhase(data.room.show_results ? 'results' : 'question');
      } else if (data.room.status === 'finished') {
        setPhase('final');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [roomId, refreshPlayers]);

  useEffect(() => {
    load();
  }, [load]);

  // Keep the lobby in sync even when Supabase Realtime is not enabled
  // for the players table in the project settings/publication.
  useEffect(() => {
    if (!roomId) return;
    void refreshPlayers();
    const poll = window.setInterval(() => {
      void refreshPlayers();
    }, 1500);
    const handleFocus = () => void refreshPlayers();
    window.addEventListener('focus', handleFocus);
    return () => {
      window.clearInterval(poll);
      window.removeEventListener('focus', handleFocus);
    };
  }, [roomId, refreshPlayers]);

  // realtime subscriptions
  useEffect(() => {
    if (!roomId) return;
    const channel = supabase
      .channel(`host-${roomId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'players', filter: `room_id=eq.${roomId}` },
        () => refreshPlayers(),
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'rooms', filter: `id=eq.${roomId}` },
        (payload) => {
          const r = payload.new as Room;
          setRoom(r);
          if (r.status === 'finished') setPhase('final');
          else if (r.status === 'playing') setPhase(r.show_results ? 'results' : 'question');
          else if (r.status === 'waiting') setPhase('lobby');
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId, refreshPlayers]);

  async function startGame() {
    if (!room) return;
    await updateRoom(room.id, { status: 'playing', current_index: 0, show_results: false });
    setPhase('question');
  }

  async function nextQuestion() {
    if (!room || !quiz) return;
    const nextIdx = room.current_index + 1;
    if (nextIdx >= quiz.questions.length) {
      await updateRoom(room.id, { status: 'finished' });
      setPhase('final');
      return;
    }
    await updateRoom(room.id, { current_index: nextIdx, show_results: false });
    setPhase('question');
    setShowLeaderboard(false);
  }

  async function showResultsScreen() {
    if (!room) return;
    await updateRoom(room.id, { show_results: true });
    setPhase('results');
    await refreshPlayers();
  }

  async function prevQuestion() {
    if (!room) return;
    const prevIdx = Math.max(0, room.current_index - 1);
    await updateRoom(room.id, { current_index: prevIdx, show_results: false });
    setPhase('question');
  }

  async function restart() {
    if (!room) return;
    await updateRoom(room.id, { status: 'waiting', current_index: 0, show_results: false });
    setPhase('lobby');
    setShowLeaderboard(false);
  }

  function copyCode() {
    if (!room) return;
    navigator.clipboard.writeText(room.code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }

  function shareLink() {
    if (!room) return;
    const url = `${window.location.origin}${window.location.pathname}#join=${room.code}`;
    if (navigator.share) {
      navigator.share({ title: 'КласКвіз — приєднуйся до гри', text: `Вводь код ${room.code} або натискай на посилання!`, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url).then(() => {
        setLinkCopied(true);
        setTimeout(() => setLinkCopied(false), 2000);
      });
    }
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900">
        <Loader2 className="animate-spin text-purple-400" size={32} />
      </div>
    );
  }

  if (!room || !quiz) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900 text-center">
        <div>
          <p className="text-slate-400">Кімнату не знайдено.</p>
          <button onClick={onBack} className="mt-4 rounded-xl bg-white/10 px-4 py-2 font-bold">
            Назад
          </button>
        </div>
      </div>
    );
  }

  // ----- LOBBY -----
  if (phase === 'lobby') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
        <header className="flex items-center justify-between px-4 py-4">
          <button
            onClick={onBack}
            className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
          >
            <ArrowLeft size={18} />
          </button>
          <span className="text-sm font-bold text-slate-400">Кімната кімнати</span>
          <div className="w-9" />
        </header>

        <main className="mx-auto flex max-w-md flex-col items-center px-4 py-6 text-center">
          <p className="mb-2 text-sm font-bold text-slate-400">Код для приєднання</p>
          <button
            onClick={copyCode}
            className="group flex items-center gap-3 rounded-3xl bg-gradient-to-br from-fuchsia-500 to-purple-600 px-8 py-4 shadow-2xl shadow-purple-500/40 transition hover:brightness-110 active:scale-95"
          >
            <span className="text-4xl font-black tracking-[0.3em]">{room.code}</span>
            <span className="rounded-lg bg-white/20 p-2 transition group-hover:bg-white/30">
              {copied ? <Check size={18} /> : <Copy size={18} />}
            </span>
          </button>
          <p className="mt-3 text-sm text-slate-400">
            Учні вводять цей код на сторінці «Приєднатись»
          </p>

          <button
            onClick={shareLink}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 py-3 font-bold transition hover:bg-white/10 active:scale-95"
          >
            {linkCopied ? <Check size={18} className="text-emerald-400" /> : <Share2 size={18} />}
            {linkCopied ? 'Посилання скопійовано!' : 'Поділитись посиланням'}
          </button>

          <div className="mt-8 w-full rounded-3xl border border-white/10 bg-white/5 p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="flex items-center gap-2 font-extrabold">
                <Users size={18} /> Гравці
              </h2>
              <span className="rounded-full bg-purple-500/20 px-3 py-0.5 text-sm font-bold text-purple-300">
                {players.length}
              </span>
            </div>
            {players.length === 0 ? (
              <p className="py-6 text-center text-sm text-slate-400">
                Очікуємо гравців… Поділися кодом!
              </p>
            ) : (
              <div className="grid max-h-60 grid-cols-2 gap-2 overflow-y-auto scroll-thin">
                {players.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-2 rounded-xl bg-white/5 px-3 py-2 text-sm font-bold animate-slide-in-left"
                  >
                    <div className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-fuchsia-500 to-purple-600 text-xs">
                      {p.nickname.charAt(0).toUpperCase()}
                    </div>
                    <span className="truncate">{p.nickname}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={startGame}
            disabled={players.length === 0}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-600 py-4 text-lg font-extrabold shadow-lg shadow-emerald-500/30 transition hover:brightness-110 active:scale-95 disabled:opacity-40"
          >
            <Play size={22} /> Почати гру
          </button>
          {players.length === 0 && (
            <p className="mt-2 text-xs text-amber-400">Потрібен хоча б один гравець</p>
          )}
        </main>
      </div>
    );
  }

  // ----- FINAL -----
  if (phase === 'final') {
    const sorted = [...players].sort((a, b) => b.score - a.score);
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-4">
        <Confetti show />
        <div className="w-full max-w-md animate-float-up text-center">
          <div className="mb-4 grid h-24 w-24 mx-auto place-items-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 shadow-2xl shadow-orange-500/40">
            <Trophy size={48} className="text-white" />
          </div>
          <h1 className="text-3xl font-black">Гру завершено!</h1>
          <p className="mt-1 text-slate-400">{quiz.title}</p>

          <div className="mt-6 space-y-2">
            {sorted.slice(0, 5).map((p, i) => (
              <div
                key={p.id}
                className={`flex items-center gap-3 rounded-2xl border p-3 ${
                  i === 0
                    ? 'border-amber-400/40 bg-amber-500/10'
                    : 'border-white/10 bg-white/5'
                }`}
              >
                <span className="grid h-9 w-9 place-items-center rounded-full bg-white/10 font-black">
                  {i + 1}
                </span>
                <span className="flex-1 text-left font-bold">{p.nickname}</span>
                <span className="font-extrabold text-amber-300">{p.score}</span>
              </div>
            ))}
          </div>

          <div className="mt-6 flex gap-3">
            <button
              onClick={restart}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 py-3 font-extrabold transition hover:brightness-110 active:scale-95"
            >
              <RotateCcw size={18} /> Ще раз
            </button>
            <button
              onClick={onHome}
              className="flex flex-1 items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 py-3 font-bold transition hover:bg-white/10"
            >
              <Home size={18} /> На головну
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ----- QUESTION / RESULTS -----
  const q = quiz.questions[room.current_index];
  const answeredCount = players.filter((p) =>
    p.answers.some((a) => a.questionId === q.id),
  ).length;

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      <header className="flex items-center justify-between px-4 py-3">
        <button
          onClick={prevQuestion}
          disabled={room.current_index === 0}
          className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10 disabled:opacity-30"
        >
          <ChevronLeft size={18} />
        </button>
        <div className="text-center">
          <div className="text-xs text-slate-400">
            Запитання {room.current_index + 1} / {quiz.questions.length}
          </div>
          <div className="text-sm font-extrabold text-purple-300">{quiz.title}</div>
        </div>
        <button
          onClick={onHome}
          className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
        >
          <Home size={18} />
        </button>
      </header>

      <main className="flex flex-1 flex-col items-center justify-center p-4">
        <div key={`${q.id}-${room.current_index}-${phase}`} className="w-full max-w-3xl animate-fade-in">
          {q.imageUrl && (
            <div className="mb-4 overflow-hidden rounded-3xl border border-white/10">
              <img src={q.imageUrl} alt="" className="max-h-48 w-full object-contain bg-black/30" />
            </div>
          )}
          <div className="mb-4 rounded-3xl border border-white/10 bg-white/5 p-5 text-center text-xl font-extrabold sm:text-2xl">
            {q.prompt || `Запитання ${room.current_index + 1}`}
          </div>

          {phase === 'question' ? (
            <>
              <div className="mb-4 flex items-center justify-center gap-2 text-sm text-slate-400">
                <Users size={15} /> Відповіли: {answeredCount} / {players.length}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {q.options.map((opt, i) => {
                  const colors = ['bg-rose-500', 'bg-sky-500', 'bg-amber-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500'];
                  return (
                    <div
                      key={opt.id}
                      className={`flex items-center gap-3 rounded-2xl ${colors[i % colors.length]} p-4 font-bold text-white opacity-90`}
                    >
                      <span className="grid h-8 w-8 place-items-center rounded-lg bg-black/20 text-sm">{i + 1}</span>
                      <span className="flex-1">{opt.text || `Варіант ${i + 1}`}</span>
                    </div>
                  );
                })}
              </div>
              <div className="mt-6 flex justify-center">
                <button
                  onClick={showResultsScreen}
                  className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 px-8 py-3 font-extrabold shadow-lg transition hover:brightness-110 active:scale-95"
                >
                  <BarChart3 size={18} /> Показати результати
                </button>
              </div>
            </>
          ) : (
            <ResultsView quiz={quiz} question={q} players={players} showLeaderboard={showLeaderboard} />
          )}
        </div>
      </main>

      {phase === 'results' && (
        <footer className="flex items-center justify-center gap-3 p-4">
          <button
            onClick={() => setShowLeaderboard((s) => !s)}
            className="flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-5 py-3 font-bold transition hover:bg-white/10"
          >
            <Trophy size={18} /> {showLeaderboard ? 'Результати' : 'Турнірна таблиця'}
          </button>
          <button
            onClick={nextQuestion}
            className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 px-8 py-3 font-extrabold shadow-lg transition hover:brightness-110 active:scale-95"
          >
            {room.current_index + 1 >= quiz.questions.length ? 'Фінал' : 'Наступне'}
            <ChevronRight size={18} />
          </button>
        </footer>
      )}
    </div>
  );
}

function ResultsView({
  quiz,
  question,
  players,
  showLeaderboard,
}: {
  quiz: Quiz;
  question: Quiz['questions'][number];
  players: Player[];
  showLeaderboard: boolean;
}) {
  if (showLeaderboard) {
    const sorted = [...players].sort((a, b) => b.score - a.score);
    return (
      <div className="space-y-2">
        <h3 className="mb-3 text-center text-lg font-extrabold text-amber-300">Турнірна таблиця</h3>
        {sorted.map((p, i) => (
          <div
            key={p.id}
            className={`flex items-center gap-3 rounded-2xl border p-3 ${
              i === 0 ? 'border-amber-400/40 bg-amber-500/10' : 'border-white/10 bg-white/5'
            }`}
          >
            <span className="grid h-8 w-8 place-items-center rounded-full bg-white/10 text-sm font-black">{i + 1}</span>
            <span className="flex-1 text-left font-bold">{p.nickname}</span>
            <span className="font-extrabold text-amber-300">{p.score}</span>
          </div>
        ))}
        {sorted.length === 0 && <p className="py-6 text-center text-slate-400">Немає гравців</p>}
      </div>
    );
  }

  // tally answers per option
  const tally = question.options.map((opt) => ({
    opt,
    count: players.filter((p) => {
      const a = p.answers.find((a) => a.questionId === question.id);
      return a && a.optionId === opt.id;
    }).length,
    correct: opt.id === question.correctOptionId,
  }));
  const total = players.length;

  return (
    <div className="space-y-3">
      <h3 className="mb-2 text-center text-lg font-extrabold text-slate-300">Результати голосування</h3>
      {tally.map((t, i) => {
        const colors = ['bg-rose-500', 'bg-sky-500', 'bg-amber-500', 'bg-emerald-500', 'bg-violet-500', 'bg-pink-500'];
        const pct = total ? Math.round((t.count / total) * 100) : 0;
        return (
          <div
            key={t.opt.id}
            className={`relative overflow-hidden rounded-2xl border p-4 ${
              t.correct ? 'border-emerald-400/50 ring-2 ring-emerald-400/30' : 'border-white/10'
            }`}
          >
            <div
              className={`absolute inset-y-0 left-0 ${colors[i % colors.length]} opacity-25 transition-all duration-700`}
              style={{ width: `${pct}%` }}
            />
            <div className="relative flex items-center justify-between">
              <span className="font-bold">
                {t.opt.text || `Варіант ${i + 1}`}
                {t.correct && <Check size={16} className="ml-2 inline text-emerald-400" />}
              </span>
              <span className="font-extrabold">
                {t.count} {total > 0 && <span className="text-sm text-slate-400">({pct}%)</span>}
              </span>
            </div>
          </div>
        );
      })}
      {total === 0 && <p className="py-4 text-center text-slate-400">Ніхто не відповів</p>}
    </div>
  );
}
