import { useEffect, useState } from 'react';
import { ArrowLeft, User, Wifi, DoorOpen, HelpCircle, Loader2, Clock } from 'lucide-react';
import { fetchQuiz, createRoom } from '@/lib/db';
import type { Quiz } from '@/lib/types';

interface ModesProps {
  quizId: string;
  onBack: () => void;
  onSolo: (quizId: string) => void;
  onHost: (roomId: string) => void;
  onJoin: () => void;
}

export function Modes({ quizId, onBack, onSolo, onHost, onJoin }: ModesProps) {
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [creatingRoom, setCreatingRoom] = useState(false);

  useEffect(() => {
    fetchQuiz(quizId)
      .then(setQuiz)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [quizId]);

  async function handleCreateRoom() {
    if (!quiz) return;
    setCreatingRoom(true);
    try {
      const { room } = await createRoom(quiz.id);
      onHost(room.id);
    } catch (e) {
      console.error(e);
      setCreatingRoom(false);
      alert('Не вдалося створити кімнату. Спробуйте ще раз.');
    }
  }

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900">
        <Loader2 className="animate-spin text-purple-400" size={32} />
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-900">
        <div className="text-center">
          <p className="text-slate-400">Вікторину не знайдено.</p>
          <button onClick={onBack} className="mt-4 rounded-xl bg-white/10 px-4 py-2 font-bold">
            Назад
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      <header className="sticky top-0 z-20 border-b border-white/10 bg-slate-900/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-4xl items-center gap-3 px-4 py-4">
          <button
            onClick={onBack}
            className="rounded-xl border border-white/10 bg-white/5 p-2 transition hover:bg-white/10"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="min-w-0">
            <p className="text-xs text-slate-400">Запустити вікторину</p>
            <h1 className="truncate text-lg font-extrabold">{quiz.title}</h1>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-10">
        <div className="mb-8 flex flex-wrap items-center gap-4 text-sm text-slate-400">
          <span className="flex items-center gap-1.5">
            <HelpCircle size={15} /> {quiz.questions.length} запитань
          </span>
          <span className="flex items-center gap-1.5">
            <Clock size={15} /> {quiz.questions.reduce((s, q) => s + q.timeLimit, 0)} сек
          </span>
        </div>

        <h2 className="mb-6 text-center text-2xl font-black">Обери режим гри</h2>

        <div className="grid gap-4 sm:grid-cols-3">
          <ModeCard
            icon={<User size={28} />}
            title="Соло"
            desc="Грай сам — перевір свої знання."
            color="from-sky-500 to-blue-600"
            disabled={quiz.questions.length === 0}
            disabledNote={quiz.questions.length === 0 ? 'Додай запитання, щоб грати' : undefined}
            onClick={() => onSolo(quizId)}
          />
          <ModeCard
            icon={<Wifi size={28} />}
            title="Створити кімнату"
            desc="Онлайн-гра з кодом для учнів."
            color="from-fuchsia-500 to-purple-600"
            disabled={quiz.questions.length === 0 || creatingRoom}
            disabledNote={quiz.questions.length === 0 ? 'Додай запитання, щоб грати' : undefined}
            onClick={handleCreateRoom}
            loading={creatingRoom}
          />
          <ModeCard
            icon={<DoorOpen size={28} />}
            title="Приєднатись"
            desc="Ввести код кімнати."
            color="from-amber-500 to-orange-600"
            onClick={onJoin}
          />
        </div>
      </main>
    </div>
  );
}

function ModeCard({
  icon,
  title,
  desc,
  color,
  onClick,
  disabled,
  disabledNote,
  loading,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  color: string;
  onClick: () => void;
  disabled?: boolean;
  disabledNote?: string;
  loading?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="group relative flex flex-col items-center overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-6 text-center transition hover:border-white/25 hover:bg-white/10 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:border-white/10 disabled:hover:bg-white/5"
    >
      <div className={`mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br ${color} shadow-lg`}>
        {loading ? <Loader2 className="animate-spin text-white" size={26} /> : icon}
      </div>
      <h3 className="text-xl font-extrabold">{title}</h3>
      <p className="mt-1 text-sm text-slate-400">{desc}</p>
      {disabledNote && <p className="mt-2 text-xs text-amber-400">{disabledNote}</p>}
    </button>
  );
}
