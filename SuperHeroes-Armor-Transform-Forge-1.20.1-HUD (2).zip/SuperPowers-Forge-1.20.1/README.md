# Super Heroes Armor & Transform (Minecraft Java 1.20.1)

Forge mod project. Includes 10 armor sets in the Creative inventory, a hero selection screen, a compact top-left key guide, transform toggle, and basic ability effects. Thor has a Mjolnir item, a multi-lightning super attack, and a lightning landing effect after a hard fall. The hammer is currently a Creative-inventory item; a true throw-and-return animation is not implemented yet.

## Controls
- **R** — transform into / return from the hero form (wear all 4 pieces of one matching armor set).
- **F** — special ability.
- **G** — super attack.
- **H** — open the hero selection screen.
- You can change these keys in Minecraft: Options → Controls → Key Binds.

The transformation is a gameplay mode with effects and abilities; it does not yet replace the player model with a custom 3D superhero skin. Armor sets are ordinary wearable items, so they remain visible when equipped.

## Build a .jar on Windows
1. Install **Java JDK 17** (Minecraft Forge 1.20.1 uses Java 17).
2. Install **IntelliJ IDEA** or **Eclipse** with Gradle support.
3. Extract this ZIP to a normal folder. Open the `SuperPowers-Forge-1.20.1` folder as a Gradle project and allow Gradle to download dependencies. Internet is needed for the first build.
4. In the IDE's Gradle panel run **Tasks → build → build**. Alternatively, in a terminal opened in this folder run `gradle build` if Gradle is installed.
5. When the build succeeds, find the mod file at `build/libs/superpowers-1.0.0.jar`. Copy that `.jar` into `%appdata%\.minecraft\mods`.
6. Launch the **Minecraft 1.20.1 Forge** profile. The client must have Forge installed.

## Important
This ZIP contains source code, not a compiled `.jar`. The build needs Gradle and internet access to download Forge dependencies. The project has not been compiled or tested in a running Minecraft client in this environment.
