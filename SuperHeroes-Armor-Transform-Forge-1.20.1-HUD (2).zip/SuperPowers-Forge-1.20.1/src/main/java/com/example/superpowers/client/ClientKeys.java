package com.example.superpowers.client;

import com.example.superpowers.SuperPowers;
import com.example.superpowers.network.PowerNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=SuperPowers.MODID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class ClientKeys {
 public static final KeyMapping MENU=new KeyMapping("key.superpowers.menu",GLFW.GLFW_KEY_H,"key.categories.superpowers");
 public static final KeyMapping TRANSFORM=new KeyMapping("key.superpowers.transform",GLFW.GLFW_KEY_R,"key.categories.superpowers");
 public static final KeyMapping LASER=new KeyMapping("key.superpowers.power1",GLFW.GLFW_KEY_F,"key.categories.superpowers");
 public static final KeyMapping PUNCH=new KeyMapping("key.superpowers.power2",GLFW.GLFW_KEY_G,"key.categories.superpowers");
 private ClientKeys(){}
 @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent e){e.register(MENU);e.register(TRANSFORM);e.register(LASER);e.register(PUNCH);}
 @Mod.EventBusSubscriber(modid=SuperPowers.MODID,value=Dist.CLIENT) public static class Events{
 @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){if(e.phase!=TickEvent.Phase.END)return;Minecraft mc=Minecraft.getInstance();while(MENU.consumeClick()){if(mc.screen==null)mc.setScreen(new TransformScreen());}while(TRANSFORM.consumeClick())PowerNetwork.send("transform");while(LASER.consumeClick())PowerNetwork.send("laser");while(PUNCH.consumeClick())PowerNetwork.send("punch");}
 }
}
