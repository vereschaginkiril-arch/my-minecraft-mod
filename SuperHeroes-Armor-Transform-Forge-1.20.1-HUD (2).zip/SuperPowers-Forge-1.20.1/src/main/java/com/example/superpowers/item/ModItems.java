package com.example.superpowers.item;

import com.example.superpowers.SuperPowers;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SuperPowers.MODID);
    public static final RegistryObject<Item> VENOM_HELMET = ITEMS.register("venom_helmet", () -> new ArmorItem(HeroArmorMaterial.VENOM, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> VENOM_CHESTPLATE = ITEMS.register("venom_chestplate", () -> new ArmorItem(HeroArmorMaterial.VENOM, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> VENOM_LEGGINGS = ITEMS.register("venom_leggings", () -> new ArmorItem(HeroArmorMaterial.VENOM, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> VENOM_BOOTS = ITEMS.register("venom_boots", () -> new ArmorItem(HeroArmorMaterial.VENOM, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> SPIDER_HELMET = ITEMS.register("spider_helmet", () -> new ArmorItem(HeroArmorMaterial.SPIDER, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> SPIDER_CHESTPLATE = ITEMS.register("spider_chestplate", () -> new ArmorItem(HeroArmorMaterial.SPIDER, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> SPIDER_LEGGINGS = ITEMS.register("spider_leggings", () -> new ArmorItem(HeroArmorMaterial.SPIDER, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> SPIDER_BOOTS = ITEMS.register("spider_boots", () -> new ArmorItem(HeroArmorMaterial.SPIDER, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> IRONMAN_HELMET = ITEMS.register("ironman_helmet", () -> new ArmorItem(HeroArmorMaterial.IRONMAN, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> IRONMAN_CHESTPLATE = ITEMS.register("ironman_chestplate", () -> new ArmorItem(HeroArmorMaterial.IRONMAN, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> IRONMAN_LEGGINGS = ITEMS.register("ironman_leggings", () -> new ArmorItem(HeroArmorMaterial.IRONMAN, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> IRONMAN_BOOTS = ITEMS.register("ironman_boots", () -> new ArmorItem(HeroArmorMaterial.IRONMAN, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> HULK_HELMET = ITEMS.register("hulk_helmet", () -> new ArmorItem(HeroArmorMaterial.HULK, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> HULK_CHESTPLATE = ITEMS.register("hulk_chestplate", () -> new ArmorItem(HeroArmorMaterial.HULK, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> HULK_LEGGINGS = ITEMS.register("hulk_leggings", () -> new ArmorItem(HeroArmorMaterial.HULK, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> HULK_BOOTS = ITEMS.register("hulk_boots", () -> new ArmorItem(HeroArmorMaterial.HULK, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> THOR_HELMET = ITEMS.register("thor_helmet", () -> new ArmorItem(HeroArmorMaterial.THOR, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> THOR_CHESTPLATE = ITEMS.register("thor_chestplate", () -> new ArmorItem(HeroArmorMaterial.THOR, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> THOR_LEGGINGS = ITEMS.register("thor_leggings", () -> new ArmorItem(HeroArmorMaterial.THOR, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> THOR_BOOTS = ITEMS.register("thor_boots", () -> new ArmorItem(HeroArmorMaterial.THOR, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> THOR_HAMMER = ITEMS.register("thor_hammer", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> WOLVERINE_HELMET = ITEMS.register("wolverine_helmet", () -> new ArmorItem(HeroArmorMaterial.WOLVERINE, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> WOLVERINE_CHESTPLATE = ITEMS.register("wolverine_chestplate", () -> new ArmorItem(HeroArmorMaterial.WOLVERINE, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> WOLVERINE_LEGGINGS = ITEMS.register("wolverine_leggings", () -> new ArmorItem(HeroArmorMaterial.WOLVERINE, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> WOLVERINE_BOOTS = ITEMS.register("wolverine_boots", () -> new ArmorItem(HeroArmorMaterial.WOLVERINE, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> DEADPOOL_HELMET = ITEMS.register("deadpool_helmet", () -> new ArmorItem(HeroArmorMaterial.DEADPOOL, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> DEADPOOL_CHESTPLATE = ITEMS.register("deadpool_chestplate", () -> new ArmorItem(HeroArmorMaterial.DEADPOOL, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> DEADPOOL_LEGGINGS = ITEMS.register("deadpool_leggings", () -> new ArmorItem(HeroArmorMaterial.DEADPOOL, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> DEADPOOL_BOOTS = ITEMS.register("deadpool_boots", () -> new ArmorItem(HeroArmorMaterial.DEADPOOL, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> BLACKPANTHER_HELMET = ITEMS.register("blackpanther_helmet", () -> new ArmorItem(HeroArmorMaterial.BLACKPANTHER, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> BLACKPANTHER_CHESTPLATE = ITEMS.register("blackpanther_chestplate", () -> new ArmorItem(HeroArmorMaterial.BLACKPANTHER, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> BLACKPANTHER_LEGGINGS = ITEMS.register("blackpanther_leggings", () -> new ArmorItem(HeroArmorMaterial.BLACKPANTHER, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> BLACKPANTHER_BOOTS = ITEMS.register("blackpanther_boots", () -> new ArmorItem(HeroArmorMaterial.BLACKPANTHER, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> CAPTAINAMERICA_HELMET = ITEMS.register("captainamerica_helmet", () -> new ArmorItem(HeroArmorMaterial.CAPTAINAMERICA, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> CAPTAINAMERICA_CHESTPLATE = ITEMS.register("captainamerica_chestplate", () -> new ArmorItem(HeroArmorMaterial.CAPTAINAMERICA, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> CAPTAINAMERICA_LEGGINGS = ITEMS.register("captainamerica_leggings", () -> new ArmorItem(HeroArmorMaterial.CAPTAINAMERICA, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> CAPTAINAMERICA_BOOTS = ITEMS.register("captainamerica_boots", () -> new ArmorItem(HeroArmorMaterial.CAPTAINAMERICA, EquipmentSlot.FEET, new Item.Properties()));
    public static final RegistryObject<Item> DOCTORSTRANGE_HELMET = ITEMS.register("doctorstrange_helmet", () -> new ArmorItem(HeroArmorMaterial.DOCTORSTRANGE, EquipmentSlot.HEAD, new Item.Properties()));
    public static final RegistryObject<Item> DOCTORSTRANGE_CHESTPLATE = ITEMS.register("doctorstrange_chestplate", () -> new ArmorItem(HeroArmorMaterial.DOCTORSTRANGE, EquipmentSlot.CHEST, new Item.Properties()));
    public static final RegistryObject<Item> DOCTORSTRANGE_LEGGINGS = ITEMS.register("doctorstrange_leggings", () -> new ArmorItem(HeroArmorMaterial.DOCTORSTRANGE, EquipmentSlot.LEGS, new Item.Properties()));
    public static final RegistryObject<Item> DOCTORSTRANGE_BOOTS = ITEMS.register("doctorstrange_boots", () -> new ArmorItem(HeroArmorMaterial.DOCTORSTRANGE, EquipmentSlot.FEET, new Item.Properties()));
    @Mod.EventBusSubscriber(modid=SuperPowers.MODID, bus=Mod.EventBusSubscriber.Bus.MOD)
    public static class CreativeTabEvents {
        @SubscribeEvent public static void addItems(BuildCreativeModeTabContentsEvent event) {
            if (event.getTabKey() == CreativeModeTabs.COMBAT) {
                ITEMS.getEntries().forEach(item -> event.accept(item.get()));
            }
        }
    }
    private ModItems() {}
}
