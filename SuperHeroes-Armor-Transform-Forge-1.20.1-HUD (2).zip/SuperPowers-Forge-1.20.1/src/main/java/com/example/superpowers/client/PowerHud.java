package com.example.superpowers.client;

import com.example.superpowers.SuperPowers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Small key-hint list, similar to the controls shown by many adventure mods. */
@Mod.EventBusSubscriber(modid = SuperPowers.MODID, value = Dist.CLIENT)
public final class PowerHud {
    private PowerHud() {}
    @SubscribeEvent
    public static void render(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        GuiGraphics g = event.getGuiGraphics();
        int x = 7, y = 8, w = 142, h = 76;
        g.fill(x, y, x + w, y + h, 0x99070712);
        g.fill(x, y, x + 2, y + h, 0xFF6E9DFF);
        g.drawString(mc.font, Component.literal("SUPER HEROES"), x + 7, y + 5, 0xFFFFFFFF, false);
        g.drawString(mc.font, Component.literal("R  Transform / back"), x + 7, y + 19, 0xFFFFD36A, false);
        g.drawString(mc.font, Component.literal("F  Special ability"), x + 7, y + 32, 0xFFFFFFFF, false);
        g.drawString(mc.font, Component.literal("G  Super attack"), x + 7, y + 45, 0xFFFFFFFF, false);
        g.drawString(mc.font, Component.literal("H  Choose hero"), x + 7, y + 58, 0xFFB9D4FF, false);
    }
}
