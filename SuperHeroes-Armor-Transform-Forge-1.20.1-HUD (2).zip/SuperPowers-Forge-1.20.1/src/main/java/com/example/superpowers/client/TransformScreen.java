package com.example.superpowers.client;

import com.example.superpowers.network.PowerNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class TransformScreen extends Screen {
 public TransformScreen(){super(Component.literal("Super Heroes"));}
 @Override protected void init(){int w=150;int x=(this.width-w)/2;int y=Math.max(24,this.height/5);addRenderableWidget(Button.builder(Component.literal("§c§lTRANSFORM"),b->{PowerNetwork.send("transform");this.onClose();}).bounds(x,y,w,24).build());addRenderableWidget(Button.builder(Component.literal("Close"),b->this.onClose()).bounds(x,y+32,w,20).build());}
 @Override public void render(GuiGraphics g,int mx,int my,float partial){renderBackground(g);super.render(g,mx,my,partial);g.drawCenteredString(this.font,"SUPER HERO ARMOR",this.width/2,Math.max(8,this.height/5-24),0xFFFFFF);g.drawCenteredString(this.font,"Wear a complete matching 4-piece set first",this.width/2,Math.max(60,this.height/5+62),0xAAAAAA);g.drawCenteredString(this.font,"F = special power  |  G = attack",this.width/2,Math.max(74,this.height/5+76),0xAAAAAA);}
 @Override public boolean isPauseScreen(){return false;}
}
