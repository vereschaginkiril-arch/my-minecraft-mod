package com.example.superpowers.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.entity.EquipmentSlot;

public enum HeroArmorMaterial implements ArmorMaterial {
    VENOM("venom", 20, 2.0F, 0.1F),
    SPIDER("spider", 20, 2.0F, 0.1F),
    IRONMAN("ironman", 20, 2.0F, 0.1F),
    HULK("hulk", 20, 2.0F, 0.1F),
    THOR("thor", 20, 2.0F, 0.1F),
    WOLVERINE("wolverine", 20, 2.0F, 0.1F),
    DEADPOOL("deadpool", 20, 2.0F, 0.1F),
    BLACKPANTHER("blackpanther", 20, 2.0F, 0.1F),
    CAPTAINAMERICA("captainamerica", 20, 2.0F, 0.1F),
    DOCTORSTRANGE("doctorstrange", 20, 2.0F, 0.1F);
    private static final int[] DURABILITY = {13, 15, 16, 11};
    private final String name;
    private final int enchant;
    private final float toughness, knockback;
    HeroArmorMaterial(String name, int enchant, float toughness, float knockback) { this.name=name; this.enchant=enchant; this.toughness=toughness; this.knockback=knockback; }
    @Override public int getDurabilityForType(EquipmentSlot slot) { return DURABILITY[slot.getIndex()]*28; }
    @Override public int getDefenseForType(EquipmentSlot slot) { return switch (slot) { case HEAD -> 3; case CHEST -> 8; case LEGS -> 6; case FEET -> 3; default -> 0; }; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_NETHERITE; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.NETHERITE_INGOT); }
    @Override public String getName() { return "superpowers:"+name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockback; }
}
