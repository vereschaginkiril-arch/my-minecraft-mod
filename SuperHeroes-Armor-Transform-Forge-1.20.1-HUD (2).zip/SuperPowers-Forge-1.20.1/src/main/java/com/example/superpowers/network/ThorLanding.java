package com.example.superpowers.network;

import com.example.superpowers.SuperPowers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Thor's powered landing: a hard fall calls down lightning around the landing point. */
@Mod.EventBusSubscriber(modid = SuperPowers.MODID)
public final class ThorLanding {
    private ThorLanding() {}
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getDistance() < 4.0F) return;
        if (!player.getPersistentData().getBoolean("sp_active") || !player.getPersistentData().getString("sp_hero").equals("thor")) return;
        event.setDamageMultiplier(0.0F);
        for (int i = 0; i < 7; i++) {
            double angle = Math.PI * 2.0 * i / 7.0;
            var bolt = EntityType.LIGHTNING_BOLT.create(player.level());
            if (bolt != null) {
                bolt.moveTo(player.getX() + Math.cos(angle) * 2.8, player.getY(), player.getZ() + Math.sin(angle) * 2.8);
                player.level().addFreshEntity(bolt);
            }
        }
    }
}
