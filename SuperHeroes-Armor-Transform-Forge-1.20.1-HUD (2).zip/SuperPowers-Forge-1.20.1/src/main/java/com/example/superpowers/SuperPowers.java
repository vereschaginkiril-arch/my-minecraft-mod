package com.example.superpowers;

import com.example.superpowers.item.ModItems;
import com.example.superpowers.network.PowerNetwork;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SuperPowers.MODID)
public class SuperPowers {
    public static final String MODID = "superpowers";
    public SuperPowers() {
        ModItems.ITEMS.register(FMLJavaModLoadingContext.get().getModEventBus());
        PowerNetwork.register();
    }
}
